﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ZeroGravitas;
using NUnitZeroGravitas;

namespace TestZeroGravitas
{
    public class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WindowHeight = 60;
                Console.WindowWidth = 150;
            }
            catch (Exception)
            { }

            try
            {
                TestBoard tb = new TestBoard();
                TestGame tg = new TestGame();

                //tg.T06_Game_PushRabbit_X();
                //tg.T01_Game_PlacePieces();
                //tg.T51_Game_LoadGame_FromFile();
                tg.T13_Game_Repeat_Board_Position();
            }
            catch (Exception ex)
            {
                Console.WriteLine("The test threw an exception. This may have been intentional, depending on the test that was run.");
                Console.WriteLine("Exception trace:\n{0}", ex.ToString());
            }
        }
    }
}
