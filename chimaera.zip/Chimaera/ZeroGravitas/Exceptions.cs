﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZeroGravitas
{
    public class InvalidMoveException : InvalidOperationException
    {
        public MoveRecord Move { get; protected set; }
        public ae.Action Action { get; protected set; }
        public ae.InvalidMove InvalidMoveReason { get; protected set; }

        public static readonly string[] msExplanations = null;

        public string Explanation
        {
            get
            {
                return msExplanations[(int)this.InvalidMoveReason];
            }
        }

        static InvalidMoveException()
        {
            int count = Enum.GetValues(typeof(ae.InvalidMove)).Length;
            msExplanations = new string[count];

            msExplanations[(int)ae.InvalidMove.Null] = "";
            msExplanations[(int)ae.InvalidMove.GameStateInvalid] = "The Game state is invalid.";
            msExplanations[(int)ae.InvalidMove.MoveObjectInvalid] = "The Move object is invalid.";
            msExplanations[(int)ae.InvalidMove.OutOfTurn] = "It is not your turn to move.";
            msExplanations[(int)ae.InvalidMove.CannotMoveEnemyPiece] = "You cannot move this enemy piece.";
            msExplanations[(int)ae.InvalidMove.InvalidStartPosition] = "The intended start position of this piece is invalid.";
            msExplanations[(int)ae.InvalidMove.PieceNotFound] = "The indicated piece was null or not found.";
            msExplanations[(int)ae.InvalidMove.OriginSquareNotFound] = "The origin square of the move was null or not found.";
            msExplanations[(int)ae.InvalidMove.DestinationSquareNotFound] = "The destination square of the move was null or not found.";
            msExplanations[(int)ae.InvalidMove.OriginSquareIncorrect] = "The residing square of the piece did not agree with the origin square of the move.";
            msExplanations[(int)ae.InvalidMove.SquaresNotAdjacent] = "The origin and destination squares are not adjacent.";
            msExplanations[(int)ae.InvalidMove.DestinationSquareOccupied] = "The destination square is currently occupied.";
            msExplanations[(int)ae.InvalidMove.InsufficientMovesRemaining] = "Not enough moves remaining in turn to complete this move.";
            msExplanations[(int)ae.InvalidMove.MustFollowThroughOnPush] = "You must follow through on the in-progress push by moving into the square vacated by the enemy piece.";
            msExplanations[(int)ae.InvalidMove.PieceFrozen] = "The piece you are attempting to move is frozen in place by an adjacent enemy piece.";
            msExplanations[(int)ae.InvalidMove.PieceTypeMovementRestricted] = "The piece you are attempting to move is not allowed to move in that direction.";
            msExplanations[(int)ae.InvalidMove.CannotPushEnemyPieceWithThisPiece] = "You cannot follow through on the push with this piece, because it is too weak.";
            msExplanations[(int)ae.InvalidMove.NoAdjacentPiecesCanPushThisPiece] = "There are no adjacent pieces capable of pushing the enemy piece that you are trying to move.";
            msExplanations[(int)ae.InvalidMove.AllAdjacentPiecesForPushingAreFrozen] = "All adjacent pieces capable of pushing this piece are currently frozen.";
            msExplanations[(int)ae.InvalidMove.CannotRepeatPreviousBoardPosition] = "You cannot make this move because it would repeat a previous board position an illegal number of times.";
            msExplanations[(int)ae.InvalidMove.MustChangeBoardPosition] = "You cannot make this move because it would duplicate the board position from the beginning of your turn.";
        }

        public InvalidMoveException(MoveRecord move, ae.Action action, ae.InvalidMove invalidMoveReason)
            : base()
        {
            this.Move = move;
            this.Action = action;
            this.InvalidMoveReason = invalidMoveReason;
        }

        public InvalidMoveException(MoveRecord move, ae.Action action, ae.InvalidMove invalidMoveReason, string message)
            : base(message)
        {
            this.Move = move;
            this.Action = action;
            this.InvalidMoveReason = invalidMoveReason;
        }

        public InvalidMoveException(MoveRecord move, ae.Action action, ae.InvalidMove invalidMoveReason, string message, Exception innerException)
            : base(message, innerException)
        {
            this.Move = move;
            this.Action = action;
            this.InvalidMoveReason = invalidMoveReason;
        }

        public static InvalidMoveException MakeInvalidMoveException(MoveRecord move, ae.Action action, ae.InvalidMove invalidMoveReason)
        {
            string explanation = msExplanations[(int)invalidMoveReason];
            string message = string.Format("Illegal move: {0}{1}.{2} {3}: {4}", move.Player.Game.WhoseTurn.Abbreviation, move.Turn, move.TurnMoveIndex + 1, move.Notation, explanation);
            return new InvalidMoveException(move, action, invalidMoveReason, message);
        }
    }
}
