﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace ZeroGravitas
{
    public class Board
    {
        public const int NumRanks = 8;
        public const int NumFiles = 8;
        public const int NumSquares = NumRanks * NumFiles;

        public const char MinFile = 'a';
        public const char MaxFile = 'h';
        public const int MinFileIndex = 0;
        public const int MaxFileIndex = NumFiles - 1;
        public const int MinRankIndex = 0;
        public const int MaxRankIndex = NumRanks - 1;

        public static readonly char[] FileNames = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
        public static readonly string[] Traps = { "c3", "c6", "f3", "f6" };

        internal static readonly int[] StartRanksGold = { 1, 2 };
        internal static readonly int[] StartRanksSilver = { 7, 8 };
        public const int WinRankIndexGold = MaxRankIndex;
        public const int WinRankIndexSilver = MinRankIndex;

        public Game Game { get; protected set; }
        public int Generation { get; protected internal set; } // incremented for every placement/move/swap/removal.
        protected internal Board Shadow { get; set; }
        protected Square[,] Squares { get; set; }

        public Board(Game game)
        {
            this.Game = game;
            Squares = new Square[NumFiles, NumRanks];
            for (int RankIndex = 0; RankIndex < NumRanks; ++RankIndex)
            {
                for (int FileIndex = 0; FileIndex < NumFiles; ++FileIndex)
                {
                    Squares[FileIndex, RankIndex] = new Square(this, FileIndex, RankIndex);
                }
            }

            for (int i = 0; i < Board.Traps.Length; ++i)
            {
                Square sq = this.GetSquare(Board.Traps[i]);
                if (sq != null)
                    sq.IsTrap = true;
            }

            for (int i = 0; i < Board.StartRanksGold.Length; ++i)
            {
                int RankIndex = Board.StartRanksGold[i] - 1;
                for (int FileIndex = 0; FileIndex < Board.NumFiles; ++FileIndex)
                {
                    Square sq = this.GetSquare(FileIndex, RankIndex);
                    if (sq != null)
                        sq.IsValidStartPositionGold = true;
                }
            }

            for (int i = 0; i < Board.StartRanksSilver.Length; ++i)
            {
                int RankIndex = Board.StartRanksSilver[i] - 1;
                for (int FileIndex = 0; FileIndex < Board.NumFiles; ++FileIndex)
                {
                    Square sq = this.GetSquare(FileIndex, RankIndex);
                    if (sq != null)
                        sq.IsValidStartPositionSilver = true;
                }
            }
        }

        public void CreateShadow()
        {
            this.Shadow = new Board(this.Game);
            for (int RankIndex = 0; RankIndex < NumRanks; ++RankIndex)
            {
                for (int FileIndex = 0; FileIndex < NumFiles; ++FileIndex)
                {
                    Squares[FileIndex, RankIndex].Shadow = this.Shadow.GetSquare(FileIndex, RankIndex);
                }
            }
        }

        #region GetSquare(...)
        public Square GetSquare(int FileIndex, int RankIndex)
        {
            return RankIndex >= 0 && FileIndex >= 0 && RankIndex < NumRanks && FileIndex < NumFiles ? Squares[FileIndex, RankIndex] : null;
        }

        public Square GetSquare(char File, int RankNumber)
        {
            return GetSquare(GetFileIndex(File), RankNumber - 1);
        }

        public Square GetSquare(string FileRank)
        {
            Match m = ae.rexPosNotation.Match(FileRank);
            if (!m.Success)
                return null;
            char File = m.Groups["f"].Value[0];
            int Rank = int.Parse(m.Groups["r"].Value);

            return GetSquare(m.Groups["f"].Value[0], int.Parse(m.Groups["r"].Value));
        }
        #endregion GetSquare(...)

        #region GetPiece(...)
        public Piece GetPiece(int FileIndex, int RankIndex)
        {
            Square sq = GetSquare(FileIndex, RankIndex);
            return sq == null ? null : sq.Piece;
        }

        public Piece GetPiece(char File, int RankNumber)
        {
            Square sq = GetSquare(File, RankNumber);
            return sq == null ? null : sq.Piece;
        }

        public Piece GetPiece(string FileRank)
        {
            Square sq = GetSquare(FileRank);
            return sq == null ? null : sq.Piece;
        }
        #endregion GetPiece(...)

        #region Helper Functions
        internal static int GetFileIndex(char FileName)
        {
            if (FileName >= MinFile && FileName <= MaxFile)
                return FileName - MinFile;
            else
                return -1;
        }

        internal static char GetDirectionChar(ae.Direction direction)
        {
            switch (direction)
            {
                case ae.Direction.North:
                    return lng.North;
                case ae.Direction.East:
                    return lng.East;
                case ae.Direction.South:
                    return lng.South;
                case ae.Direction.West:
                    return lng.West;
                default:
                    return lng.UnknownDirection;
            }
        }

        public static ae.Direction GetDirection(char direction)
        {
            switch (direction)
            {
                case lng.North:
                    return ae.Direction.North;
                case lng.East:
                    return ae.Direction.East;
                case lng.South:
                    return ae.Direction.South;
                case lng.West:
                    return ae.Direction.West;
                default:
                    return ae.Direction.Null;
            }
        }
        #endregion Helper Functions

        #region Debugging
        public char[] ToCharArray()
        {
            char[] rep = new char[Board.NumSquares];
            int k = 0;
            for (int RankIndex = 0; RankIndex < Board.NumRanks; ++RankIndex)
            {
                for (int FileIndex = 0; FileIndex < Board.NumFiles; ++FileIndex)
                {
                    rep[k++] = this.Squares[FileIndex, RankIndex].Abbreviation;
                }
            }
            return rep;
        }

        public char[,] GetRepresentation()
        {
            char[,] rep = new char[NumFiles, NumRanks];

            for (int RankIndex = 0; RankIndex < Board.NumRanks; ++RankIndex)
            {
                for (int FileIndex = 0; FileIndex < Board.NumFiles; ++FileIndex)
                {
                    rep[FileIndex, Board.MaxRankIndex - RankIndex] = this.Squares[FileIndex, RankIndex].Abbreviation;
                }
            }

            return rep;
        }

        public override string ToString()
        {
            Square square;
            StringBuilder sb = new StringBuilder(NumRanks * (NumFiles + 2));

            for (int RankIndex = 0; RankIndex < Board.NumRanks; RankIndex++)
            {
                for (int FileIndex = 0; FileIndex < Board.NumFiles; FileIndex++)
                {
                    square = GetSquare(FileIndex, Board.MaxRankIndex - RankIndex);
                    sb.Append(square.Abbreviation);
                }
                sb.AppendLine();
            }
            return sb.ToString();
        }
        #endregion Debugging
    }
}
