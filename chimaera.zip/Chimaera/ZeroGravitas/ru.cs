﻿using System;

namespace ZeroGravitas
{
    public class ru
    {
        public const int AverageIncidentalMoves = 1;
        public const int AverageTurnsPerGame = 64;
        public const int MaxBoardRepeatsAllowed = 2;

        public const int NumPlayers = 2;
        public const int MovesPerTurn = 4;

        public const int NumPieceTypes = 6;
        public const int NumRabbits = 8;
        public const int NumCats = 2;
        public const int NumDogs = 2;
        public const int NumHorses = 2;
        public const int NumCamels = 1;
        public const int NumElephants = 1;
        public const int NumPieces = NumRabbits + NumCats + NumDogs + NumHorses + NumCamels + NumElephants;
    }
}
