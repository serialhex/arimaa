﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace ZeroGravitas
{
    public class TurnRecord : List<MoveRecord>
    {
        public int TurnNumber { get; protected set; }
        public Player Player { get; protected set; }
        public string Name { get { return string.Concat( this.TurnNumber, this.Player == null ? '?' : this.Player.Abbreviation ); } }

        public TurnRecord()
            : base()
        {
            this.TurnNumber = 0;
            this.Player = null;
        }

        public TurnRecord(int turn, Player player)
            : base()
        {
            this.TurnNumber = turn;
            this.Player = player;
        }

        public TurnRecord(int turn, Player player, int capacity)
            : base(capacity)
        {
            this.TurnNumber = turn;
            this.Player = player;
        }

        public TurnRecord(TurnRecord other)
            : base(other)
        {
            this.TurnNumber = other.TurnNumber;
            this.Player = other.Player;
        }

        public TurnRecord(int turn, Player player, IEnumerable<MoveRecord> collection)
            : base(collection)
        {
            this.TurnNumber = turn;
            this.Player = player;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(128);
            if (this.Count != 0)
                this[0].AppendNotation(sb);
            for (int i = 1; i < this.Count; ++i)
            {
                sb.Append(' ');
                this[i].AppendNotation(sb);
            }
            return sb.ToString();
        }

        public List<MoveRecord> GetUndoMoves()
        {
            List<MoveRecord> unmoves = new List<MoveRecord>(this.Count);
            for (int i = this.Count - 1; i >= 0; --i)
                this[i].AddUndoMoves(unmoves);
            return unmoves;
        }
    }
}
