﻿/*
 * ZeroGravitas is an engine for playing a chess variant called Arimaa®.
 * 
 * This project is provided with the written authorization of Arimaa.com
 * and in compliance with Section III of the Arimaa Public License. Any 
 * derivatives of this project must also comply with the Arimaa Public 
 * License. The Arimaa name is a registered trademark, and the Arimaa 
 * game is patented. The Arimaa rules, the Arimaa board, and the Arimaa 
 * piece design are all protected by copyright.

 * The latest revision of the Arimaa Public License can be found at:
 * http://arimaa.com/arimaa/license/current.txt
 * 
 * Please visit the official Arimaa web site.
 * http://arimaa.com/arimaa
 * 
 * The latest version of this project can always be found at:
 * http://www.wwddfd.com/arimaa/
 * 
 * Scott P Hensel
 * scott@wwddfd.com
 */

using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace ZeroGravitas
{
    public class Game
    {
        #region Properties
        public int GameId { get; protected set; }
        public Board Board { get; protected set; }
        public Player Gold { get; protected set; }
        public Player Silver { get; protected set; }
        public int Tick { get; protected set; }
        public int TurnNumber { get; protected set; }
        public int TurnMoveIndex { get; protected set; }
        public int MovesLeftThisTurn { get { return ru.MovesPerTurn - this.TurnMoveIndex; } }
        public Player WhoseTurn { get; protected set; }
        public ae.GameState State { get; protected set; }
        public bool Cheating { get; set; }
        protected bool CheatingInternal { get; set; }

        public List<TurnRecord> TurnsFuture { get; protected set; }
        public List<TurnRecord> Turns { get; protected set; }
        public TurnRecord CurTurn { get { return Turns.Count == 0 ? null : Turns[Turns.Count - 1]; } }
        public MoveRecord PrevMove { get { return CurTurn.Count == 0 ? null : CurTurn[CurTurn.Count - 1]; } }
        protected Dictionary<string, int[]> dicPreviousBoardLayoutsPerPlayer { get; set; }
        #endregion Properties

        #region Constructors
        public Game()
        {
            this.State = ae.GameState.Null;
            this.TurnNumber = 1;
            this.Tick = 0;
            this.Board = new Board(this);
            this.Gold = new Player(this, ae.PlayerColor.Gold, ae.Intelligence.Human);
            this.Silver = new Player(this, ae.PlayerColor.Silver, ae.Intelligence.Human);

            this.Board.CreateShadow();
            this.Gold.CreateShadow();
            this.Silver.CreateShadow();

            this.Turns = new List<TurnRecord>(ru.AverageTurnsPerGame);
            this.TurnsFuture = new List<TurnRecord>(ru.AverageTurnsPerGame);
            this.dicPreviousBoardLayoutsPerPlayer = new Dictionary<string, int[]>(ru.AverageTurnsPerGame);
        }

        public Game(int gameId)
            : this()
        {
            this.GameId = gameId;
        }
        #endregion Constructors

        #region Properties
        public ae.GameStateType StateType
        {
            get
            {
                switch (this.State)
                {
                    case ae.GameState.Initialization:
                        return ae.GameStateType.Initialization;
                    case ae.GameState.GoldSetup:
                    case ae.GameState.SilverSetup:
                        return ae.GameStateType.Setup;
                    case ae.GameState.GoldsTurn:
                    case ae.GameState.SilversTurn:
                        return ae.GameStateType.Play;
                    case ae.GameState.GoldWins:
                    case ae.GameState.SilverWins:
                        return ae.GameStateType.End;
                    case ae.GameState.Null:
                    default:
                        return ae.GameStateType.Null;
                }
            }
        }
        #endregion Properties

        #region Game State Functions
        public int GetBoardLayoutRepeatCount(ae.PlayerColor playerColor, char[] boardLayout)
        {
            return this.GetBoardLayoutRepeatCount(playerColor, new string(boardLayout));
        }

        public int GetBoardLayoutRepeatCount(ae.PlayerColor playerColor, string boardLayout)
        {
            int[] cc = null;
            if (this.dicPreviousBoardLayoutsPerPlayer.TryGetValue(boardLayout, out cc))
                return cc[(int)playerColor];
            else return 0;
        }

        public void SetBoardLayoutRepeatCount(ae.PlayerColor playerColor, string boardLayout, int count)
        {
            int[] cc = null;
            if (!this.dicPreviousBoardLayoutsPerPlayer.TryGetValue(boardLayout, out cc))
            {
                cc = new int[ru.NumPlayers];
                this.dicPreviousBoardLayoutsPerPlayer.Add(boardLayout, cc);
            }
            cc[(int)playerColor] += 1;
        }

        public bool StartGame()
        {
            switch (this.State)
            {
                case ae.GameState.Initialization:
                case ae.GameState.GoldSetup:
                case ae.GameState.SilverSetup:
                    SwitchTurn(this.Gold, true);
                    break;
                default:
                    break;
            }
            return true;
        }

        public void SwitchTurn(Player SwitchToThisPlayer, bool advanceTurnNumber)
        {
            // TODO: Must not repeat board position from last turn for same player.
            if (SwitchToThisPlayer.Game != this)
                throw new ArgumentException("player.Game != Game");

            if (this.TurnMoveIndex == 0 && this.StateType != ae.GameStateType.Setup && this.StateType != ae.GameStateType.Initialization)
                throw new InvalidOperationException("Player must move at least once!");

            MoveRecord prevMove = this.PrevMove;
            if (prevMove != null)
            {
                switch (prevMove.Action)
                {
                    case ae.Action.PushedByOther:
                        throw new InvalidOperationException("You must follow through on the two-step push of an enemy piece!");
                    case ae.Action.Takeback:
                        TurnRecord t = GetBeginningOfTakebacks();
                        this.TurnNumber = t.TurnNumber;
                        this.WhoseTurn = this.GetPlayer(t.Player.Color == ae.PlayerColor.Gold ? ae.PlayerColor.Silver : ae.PlayerColor.Gold);
                        SwitchToThisPlayer = t.Player;
                        advanceTurnNumber = false;
                        break;
                    default:
                        break;
                }
            }

            string boardLayout = new string(this.Board.ToCharArray());

            if (boardLayout == this.WhoseTurn.LastBoardPosition)
            {
                throw new InvalidOperationException("You cannot end your turn now, because it would leave the board position unchanged from the start of your turn.");
            }

            int count = this.GetBoardLayoutRepeatCount(SwitchToThisPlayer.Color, boardLayout);
            if (count == ru.MaxBoardRepeatsAllowed)
            {
                if (this.TurnMoveIndex == ru.MovesPerTurn)
                {
                    // TODO: Make sure that the initial board layout is counted when the game starts.
                    // TODO: Board position repeated too many times; the other player wins! Shove this into CheckForWinningConditions() somehow.
                }
                else
                    throw new InvalidOperationException("You cannot end your turn now, because it would repeat the board position too many times.");
            }
            else
            {
                this.SetBoardLayoutRepeatCount(SwitchToThisPlayer.Color, boardLayout, ++count);
            }

            if (advanceTurnNumber)
                this.TurnNumber += 1;

            this.TurnMoveIndex = 0;
            this.State = CheckForWinningConditions(this.WhoseTurn);
            this.WhoseTurn = SwitchToThisPlayer;
            this.Turns.Add(new TurnRecord(this.TurnNumber, SwitchToThisPlayer, ru.MovesPerTurn));
            this.WhoseTurn.LastBoardPosition = boardLayout;
        }

        public void SwitchTurn(ae.PlayerColor playerColor, bool advanceTurnNumber)
        {
            SwitchTurn(GetPlayer(playerColor), advanceTurnNumber);
        }

        public ae.GameState CheckForWinningConditions(Player whoseTurnJustEnded)
        {
            bool noRabbitsRemainingGold = this.Gold.RabbitsOnBoard == 0;
            bool noRabbitsRemainingSilver = this.Silver.RabbitsOnBoard == 0;

            if (noRabbitsRemainingGold && noRabbitsRemainingSilver)
                return whoseTurnJustEnded.Color == ae.PlayerColor.Gold ? ae.GameState.GoldWins : ae.GameState.SilverWins;
            if (noRabbitsRemainingGold)
                return ae.GameState.SilverWins;
            if (noRabbitsRemainingSilver)
                return ae.GameState.GoldWins;

            if (this.Gold.RabbitsAtFinishLine)
                return ae.GameState.GoldWins;
            if (this.Silver.RabbitsAtFinishLine)
                return ae.GameState.SilverWins;

            return whoseTurnJustEnded.Color == ae.PlayerColor.Gold ? ae.GameState.SilversTurn : ae.GameState.GoldsTurn;
        }

        public bool Advance()
        {
            switch (this.State)
            {
                case ae.GameState.Null:
                case ae.GameState.Initialization:
                    this.State = ae.GameState.GoldSetup;
                    this.WhoseTurn = this.Gold;
                    this.Turns.Add(new TurnRecord(this.TurnNumber, this.Gold, 16));
                    break;
                case ae.GameState.GoldSetup:
                    // TODO: Must place all pieces (except rabbits), unless giving odds?
                    this.State = ae.GameState.SilverSetup;
                    this.WhoseTurn = this.Silver;
                    this.Turns.Add(new TurnRecord(this.TurnNumber, this.Silver, 16));
                    break;
                case ae.GameState.SilverSetup:
                    // TODO: Must place all pieces (except rabbits), unless giving odds?
                    this.StartGame();
                    break;
                case ae.GameState.GoldsTurn:
                    SwitchTurn(this.Silver, false);
                    break;
                case ae.GameState.SilversTurn:
                    SwitchTurn(this.Gold, true);
                    break;
                case ae.GameState.GoldWins:
                case ae.GameState.SilverWins:
                    return false;
                default:
                    throw new ArgumentOutOfRangeException("Game.State");
            }
            return true;
        }
        #endregion Game State Functions

        #region IsLegalMove/Play
        public ae.InvalidMove IsLegalMove(MoveRecord move, out ae.Action action)
        {
            action = ae.Action.Null;

            if (!move.Valid)
                return ae.InvalidMove.MoveObjectInvalid;

            if (this.CheatingInternal || this.Cheating)
            {
                if (!(move.Player.Game.Board == move.To.Board && (move.From == null || move.From.Board == move.To.Board)))
                    return ae.InvalidMove.MoveObjectInvalid;
                if (move.Piece == null)
                    return ae.InvalidMove.PieceNotFound;                // null references
                if (move.From != null && move.From.Piece != move.Piece)
                    return ae.InvalidMove.OriginSquareIncorrect;        // piece's origin square incorrect
                if (move.From != null && move.Piece.Player.Game.Board != move.From.Board)
                    return ae.InvalidMove.MoveObjectInvalid;            // different boards
                if (move.To != null && move.Piece.Player.Game.Board != move.To.Board)
                    return ae.InvalidMove.MoveObjectInvalid;            // different boards
                if (move.To != null && move.To.Piece != null)
                    return ae.InvalidMove.DestinationSquareOccupied;    // destination square occupied
                return ae.InvalidMove.Null;
            }

            switch (this.State)
            {
                case ae.GameState.Initialization:
                    if (move.Piece == null)
                        return ae.InvalidMove.PieceNotFound;
                    if (move.To == null)
                        return ae.InvalidMove.DestinationSquareNotFound;
                    return ae.InvalidMove.Null;
                case ae.GameState.GoldSetup:
                    action = ae.Action.Place;
                    if (move.Piece == null)
                        return ae.InvalidMove.PieceNotFound;
                    if (move.To == null)
                        return ae.InvalidMove.DestinationSquareNotFound;
                    if (move.Player.Color != ae.PlayerColor.Gold)
                        return ae.InvalidMove.OutOfTurn;
                    if (move.Piece.Player.Color != ae.PlayerColor.Gold)
                        return ae.InvalidMove.CannotMoveEnemyPiece;
                    if (!move.To.IsValidStartPositionGold)
                        return ae.InvalidMove.InvalidStartPosition;
                    if (move.From != null && move.From.Piece != move.Piece)
                        return ae.InvalidMove.OriginSquareIncorrect;
                    return ae.InvalidMove.Null;
                case ae.GameState.SilverSetup:
                    action = ae.Action.Place;
                    if (move.Piece == null)
                        return ae.InvalidMove.PieceNotFound;
                    if (move.To == null)
                        return ae.InvalidMove.DestinationSquareNotFound;
                    if (move.Player.Color != ae.PlayerColor.Silver)
                        return ae.InvalidMove.OutOfTurn;
                    if (move.Piece.Player.Color != ae.PlayerColor.Silver)
                        return ae.InvalidMove.CannotMoveEnemyPiece;
                    if (!move.To.IsValidStartPositionSilver)
                        return ae.InvalidMove.InvalidStartPosition;
                    if (move.From != null && move.From.Piece != move.Piece)
                        return ae.InvalidMove.OriginSquareIncorrect;
                    return ae.InvalidMove.Null;
                case ae.GameState.GoldsTurn:
                case ae.GameState.SilversTurn:
                    return IsLegalPlay(move, out action);
                case ae.GameState.Null:
                case ae.GameState.GoldWins:
                case ae.GameState.SilverWins:
                default:
                    return ae.InvalidMove.GameStateInvalid;
            }
        }

        protected ae.InvalidMove IsLegalPlay(MoveRecord move, out ae.Action action)
        {
            action = ae.Action.Null;

            if (move.Player.Color != this.WhoseTurn.Color)
                return ae.InvalidMove.OutOfTurn;                    // player making a move out of turn
            if (move.From == null)
                return ae.InvalidMove.OriginSquareNotFound;         // null references
            if (move.To == null)
                return ae.InvalidMove.DestinationSquareNotFound;    // null references
            if (move.Piece == null)
                return ae.InvalidMove.PieceNotFound;                // null references
            if (move.From.Piece != move.Piece)
                return ae.InvalidMove.OriginSquareIncorrect;        // piece's origin square incorrect
            if (move.Piece.Player.Game.Board != move.From.Board || move.From.Board != move.To.Board)
                return ae.InvalidMove.MoveObjectInvalid;            // different boards
            if (Math.Abs(move.From.File - move.To.File) + Math.Abs(move.From.Rank - move.To.Rank) != 1)
                return ae.InvalidMove.SquaresNotAdjacent;           // only one horizontal or one vertical move is allowed
            if (move.To.Piece != null)
                return ae.InvalidMove.DestinationSquareOccupied;    // destination square occupied

            MoveRecord prevMove = this.PrevMove;
            if (prevMove != null && prevMove.Player.Color != move.Player.Color)
                prevMove = null; // don't even look at the other player's move; it's irrelevant.

            if (move.Piece.Player.Color == move.Player.Color)
            {   // moving player's own piece...

                // assume normal move by default.
                action = ae.Action.Move;

                if (prevMove != null)
                {   // check player's previous action this turn...
                    if (prevMove.Piece.Player.Color != prevMove.Player.Color)
                    {   // player moved enemy piece last turn...
                        if (prevMove.Action == ae.Action.PushedByOther)
                        {   // last move was a push, so this move must be the follow-through.
                            action = ae.Action.PushOther;
                        }
                    }
                }
            }
            else
            {   // moving an enemy piece...
                if (prevMove != null)
                {   // check player's previous action this turn...
                    if (prevMove.Piece.Player.Color == prevMove.Player.Color)
                    {   // player's last move was her own piece. See if this is a pull or a push...
                        if (prevMove.From == move.To && prevMove.Action == ae.Action.Move && prevMove.Piece.CanPull(move.Piece))
                        {   // last piece vacated this move's destination square.
                            // only a normal move can end with a pull.
                            // the piece from the previous move must also be strong enough to pull the current piece.
                            action = ae.Action.PulledByOther;
                        }
                        else
                        {   // else it must be the start of a push.
                            action = ae.Action.PushedByOther;
                        }
                    }
                    else
                    {   // the last piece moved was an enemy piece, so if we're moving an enemy piece again, it must be the first step of a push...
                        action = ae.Action.PushedByOther;
                    }
                }
                else
                {   // this is the first action this turn, so it must be the start of a push.
                    action = ae.Action.PushedByOther;
                }
            }

            ae.InvalidMove tmp = ae.InvalidMove.Null;
            switch (action)
            {
                case ae.Action.Move:
                    if (this.MovesLeftThisTurn < 1)
                        return ae.InvalidMove.InsufficientMovesRemaining; // requires 1 move.
                    if (prevMove != null && prevMove.Action == ae.Action.PushedByOther)
                        return ae.InvalidMove.MustFollowThroughOnPush; // can't move if in the middle of another push.
                    if (move.Piece.IsFrozen)
                        return ae.InvalidMove.PieceFrozen; // can't move if frozen
                    ae.Movement movementAllowed = move.Piece.Movement;
                    if (movementAllowed != ae.Movement.All)
                    {
                        ae.Direction dir = move.From.GetDirectionToAdjacent(move.To);
                        if (move.Player.Color == ae.PlayerColor.Gold)
                        {
                            switch (dir)
                            {
                                case ae.Direction.North:
                                    if ((movementAllowed & ae.Movement.Forward) == ae.Movement.Null)
                                        return ae.InvalidMove.PieceTypeMovementRestricted;
                                    break;
                                case ae.Direction.East:
                                    if ((movementAllowed & ae.Movement.Right) == ae.Movement.Null)
                                        return ae.InvalidMove.PieceTypeMovementRestricted;
                                    break;
                                case ae.Direction.South:
                                    if ((movementAllowed & ae.Movement.Backward) == ae.Movement.Null)
                                        return ae.InvalidMove.PieceTypeMovementRestricted;
                                    break;
                                case ae.Direction.West:
                                    if ((movementAllowed & ae.Movement.Left) == ae.Movement.Null)
                                        return ae.InvalidMove.PieceTypeMovementRestricted;
                                    break;
                                default:
                                    throw new NotImplementedException("Unknown direction!");
                            }
                        }
                        else
                        {
                            switch (dir)
                            {
                                case ae.Direction.North:
                                    if ((movementAllowed & ae.Movement.Backward) == ae.Movement.Null)
                                        return ae.InvalidMove.PieceTypeMovementRestricted;
                                    break;
                                case ae.Direction.East:
                                    if ((movementAllowed & ae.Movement.Left) == ae.Movement.Null)
                                        return ae.InvalidMove.PieceTypeMovementRestricted;
                                    break;
                                case ae.Direction.South:
                                    if ((movementAllowed & ae.Movement.Forward) == ae.Movement.Null)
                                        return ae.InvalidMove.PieceTypeMovementRestricted;
                                    break;
                                case ae.Direction.West:
                                    if ((movementAllowed & ae.Movement.Right) == ae.Movement.Null)
                                        return ae.InvalidMove.PieceTypeMovementRestricted;
                                    break;
                                default:
                                    throw new NotImplementedException("Unknown direction!");
                            }
                        }
                    }
                    if (this.MovesLeftThisTurn == 1)
                    {
                        tmp = DetermineBoardPositionRepetition(move, action);
                        if (tmp != ae.InvalidMove.Null)
                            return tmp;
                    }
                    break;
                case ae.Action.PullOther:
                    throw new InvalidOperationException("We can't know we're pulling until the next move!");
                case ae.Action.PushOther: // prevMove is guaranteed not to be null for PushOther.
                    if (this.MovesLeftThisTurn < 1)
                        throw new InvalidOperationException("Something is wrong. You shouldn't have been able to push in the first place if there are no moves left with which to follow-through!");
                    if (move.To != prevMove.From)
                        return ae.InvalidMove.MustFollowThroughOnPush; // Must follow through by moving onto the square vacated by the pushed piece.
                    if (!move.Piece.CanPush(prevMove.Piece))
                        return ae.InvalidMove.CannotPushEnemyPieceWithThisPiece; // Current piece is too weak to follow through on the push.
                    if (this.MovesLeftThisTurn == 1)
                    {
                        tmp = DetermineBoardPositionRepetition(move, action);
                        if (tmp != ae.InvalidMove.Null)
                            return tmp;
                    }
                    break;
                case ae.Action.PulledByOther: // prevMove is guaranteed not to be null for PulledByOther.
                    // The other checks for this type of movement are up above.
                    // It is necessary to perform them earlier, because if they fail, then this move is actually the first step of a push!
                    // Note that a piece can be pulled even if the piece doing the pulling has fallen into a trap square!
                    if (this.MovesLeftThisTurn < 1)
                        return ae.InvalidMove.InsufficientMovesRemaining; // requires 1 move.
                    if (this.MovesLeftThisTurn == 1)
                    {
                        tmp = DetermineBoardPositionRepetition(move, action);
                        if (tmp != ae.InvalidMove.Null)
                            return tmp;
                    }
                    break;
                case ae.Action.PushedByOther:
                    if (this.MovesLeftThisTurn < 2)
                        return ae.InvalidMove.InsufficientMovesRemaining; // requires 2 moves!
                    if (prevMove != null && prevMove.Action == ae.Action.PushedByOther)
                        return ae.InvalidMove.MustFollowThroughOnPush; // can't push if in the middle of another push.

                    ae.DirFlag pushers = move.Piece.Pushers;
                    if (pushers == ae.DirFlag.Null)
                        return ae.InvalidMove.NoAdjacentPiecesCanPushThisPiece; // there are no adjacent pieces capable of pushing.

                    bool canBePushed = false;
                    if (!canBePushed && (pushers & ae.DirFlag.North) != ae.DirFlag.Null && !move.From.PieceNorth.IsFrozen)
                        canBePushed = true; // pusher to north is not frozen
                    if (!canBePushed && (pushers & ae.DirFlag.East) != ae.DirFlag.Null && !move.From.PieceEast.IsFrozen)
                        canBePushed = true; // pusher to east is not frozen
                    if (!canBePushed && (pushers & ae.DirFlag.South) != ae.DirFlag.Null && !move.From.PieceSouth.IsFrozen)
                        canBePushed = true; // pusher to south is not frozen
                    if (!canBePushed && (pushers & ae.DirFlag.West) != ae.DirFlag.Null && !move.From.PieceWest.IsFrozen)
                        canBePushed = true; // pusher to west is not frozen
                    if (!canBePushed)
                        return ae.InvalidMove.AllAdjacentPiecesForPushingAreFrozen;
                    if (this.MovesLeftThisTurn == 2)
                    {
                        tmp = DetermineBoardPositionRepetition(move, action);
                        if (tmp != ae.InvalidMove.Null)
                            return tmp;
                    }
                    break;
                case ae.Action.Remove:
                case ae.Action.Place:
                default:
                    throw new InvalidOperationException("How did this case block get hit?");
            }

            return ae.InvalidMove.Null;
        }

        public ae.InvalidMove DetermineBoardPositionRepetition(MoveRecord move, ae.Action action)
        {
            this.Gold.SyncShadow();
            this.Silver.SyncShadow();
            this.Board.Shadow.Generation += 1;

            //if (this.Board.ToString() != this.Board.Shadow.ToString())
            //    throw new Exception("Board and Board.Shadow are not synced!");

            // NOTE: There is no need to account for trapped pieces. When a piece is removed from play, it permanently changes the board layout possibilities.
            // I could actually clear() the dictionary of board layouts whenever a piece is trapped, but this would conflict with undos and takebacks.

            ae.PlayerColor nextPlayer;
            switch (move.PlayerColor)
            {
                case ae.PlayerColor.Gold:
                    nextPlayer = ae.PlayerColor.Silver;
                    break;
                case ae.PlayerColor.Silver:
                    nextPlayer = ae.PlayerColor.Gold;
                    break;
                default:
                    throw new ArgumentOutOfRangeException("move.PlayerColor");
            }

            switch (action)
            {
                case ae.Action.PushedByOther:
                    // Must consider the move after the next move.
                    ae.DirFlag pushers = move.Piece.Pushers;

                    MovePieceShadow(move);
                    //string boardShadowBaseLayout = this.Board.Shadow.ToString();

                    Square stmp = null;
                    Piece ptmp = null;
                    MoveRecord mtmp = null;
                    string boardLayout = null;
                    bool repeatA = true, repeatB = true;

                    if ((repeatA || repeatB) && (pushers & ae.DirFlag.North) != ae.DirFlag.Null)
                    {
                        if (mtmp != null)
                            this.UndoMovePieceShadow(mtmp);
                        //if (boardShadowBaseLayout != this.Board.Shadow.ToString()) // DEBUG
                        //    throw new Exception("Board and Board.Shadow are not synced!");
                        stmp = move.From.Shadow.SquareNorth;
                        ptmp = stmp.Piece;

                        if (!ptmp.IsFrozen)
                        {
                            mtmp = new MoveRecord(move.Player, ptmp, stmp, move.From.Shadow);
                            MovePiece(mtmp);
                            boardLayout = new string(this.Board.Shadow.ToCharArray());
                            if (repeatA && boardLayout != move.Player.LastBoardPosition)
                                repeatA = false;
                            if (repeatB && GetBoardLayoutRepeatCount(nextPlayer, boardLayout) < ru.MaxBoardRepeatsAllowed)
                                repeatB = false;
                        }
                    }

                    if ((repeatA || repeatB) && (pushers & ae.DirFlag.East) != ae.DirFlag.Null)
                    {
                        if (mtmp != null)
                            this.UndoMovePieceShadow(mtmp);
                        //if (boardShadowBaseLayout != this.Board.Shadow.ToString()) // DEBUG
                        //    throw new Exception("Board and Board.Shadow are not synced!");
                        stmp = move.From.Shadow.SquareEast;
                        ptmp = stmp.Piece;

                        if (!ptmp.IsFrozen)
                        {
                            mtmp = new MoveRecord(move.Player, ptmp, stmp, move.From.Shadow);
                            MovePiece(mtmp);
                            boardLayout = new string(this.Board.Shadow.ToCharArray());
                            if (repeatA && boardLayout != move.Player.LastBoardPosition)
                                repeatA = false;
                            if (repeatB && GetBoardLayoutRepeatCount(nextPlayer, boardLayout) < ru.MaxBoardRepeatsAllowed)
                                repeatB = false;
                        }
                    }

                    if ((repeatA || repeatB) && (pushers & ae.DirFlag.South) != ae.DirFlag.Null)
                    {
                        if (mtmp != null)
                            this.UndoMovePieceShadow(mtmp);
                        //if (boardShadowBaseLayout != this.Board.Shadow.ToString()) // DEBUG
                        //    throw new Exception("Board and Board.Shadow are not synced!");
                        stmp = move.From.Shadow.SquareSouth;
                        ptmp = stmp.Piece;

                        if (!ptmp.IsFrozen)
                        {
                            mtmp = new MoveRecord(move.Player, ptmp, stmp, move.From.Shadow);
                            MovePiece(mtmp);
                            boardLayout = new string(this.Board.Shadow.ToCharArray());
                            if (repeatA && boardLayout != move.Player.LastBoardPosition)
                                repeatA = false;
                            if (repeatB && GetBoardLayoutRepeatCount(nextPlayer, boardLayout) < ru.MaxBoardRepeatsAllowed)
                                repeatB = false;
                        }
                    }

                    if ((repeatA || repeatB) && (pushers & ae.DirFlag.West) != ae.DirFlag.Null)
                    {
                        if (mtmp != null)
                            this.UndoMovePieceShadow(mtmp);
                        //if (boardShadowBaseLayout != this.Board.Shadow.ToString()) // DEBUG
                        //    throw new Exception("Board and Board.Shadow are not synced!");
                        stmp = move.From.Shadow.SquareWest;
                        ptmp = stmp.Piece;

                        if (!ptmp.IsFrozen)
                        {
                            mtmp = new MoveRecord(move.Player, ptmp, stmp, move.From.Shadow);
                            MovePiece(mtmp);
                            boardLayout = new string(this.Board.Shadow.ToCharArray());
                            if (repeatA && boardLayout != move.Player.LastBoardPosition)
                                repeatA = false;
                            if (repeatB && GetBoardLayoutRepeatCount(nextPlayer, boardLayout) < ru.MaxBoardRepeatsAllowed)
                                repeatB = false;
                        }
                    }

                    if (repeatA)
                        return ae.InvalidMove.MustChangeBoardPosition;
                    if (repeatB)
                        return ae.InvalidMove.CannotRepeatPreviousBoardPosition;

                    break;
                default:
                    // Must consider only the next move.
                    MovePieceShadow(move);
                    boardLayout = new string(this.Board.Shadow.ToCharArray());
                    if (boardLayout == move.Player.LastBoardPosition)
                        return ae.InvalidMove.MustChangeBoardPosition;
                    if (GetBoardLayoutRepeatCount(nextPlayer, boardLayout) >= ru.MaxBoardRepeatsAllowed)
                        return ae.InvalidMove.CannotRepeatPreviousBoardPosition;
                    break;
            }

            return ae.InvalidMove.Null;
        }
        #endregion IsLegalMove/Play

        #region Helper Functions
        public Piece GetFreePieceForSetup(ae.PlayerColor playerColor, ae.PieceType pieceType)
        {
            Piece found = null;

            // Try to find a free piece of the correct type in the player's collection...
            Player player = playerColor == ae.PlayerColor.Gold ? this.Gold : this.Silver;
            Piece[] pieces = player.GetPieces(pieceType);

            foreach (Piece piece in pieces)
            {
                if (piece != null && piece.Square == null)
                {
                    found = piece; // found a "free" (unplaced) piece.
                    break;
                }
            }

            if (found == null && pieces.Length != 0) // if no free pieces were found, select the first piece of this type.
                found = pieces[0];

            if (found == null)
                throw new ArgumentException(string.Format("No pieces of type {0} were found.", pieceType.ToString()));

            return found;
        }

        public Player GetPlayer(ae.PlayerColor playerColor)
        {
            switch (playerColor)
            {
                case ae.PlayerColor.Gold:
                    return this.Gold;
                case ae.PlayerColor.Silver:
                    return this.Silver;
                default:
                    throw new ArgumentOutOfRangeException("playerColor");
            }
        }
        #endregion Helper Functions

        #region Initialize
        public bool InitializeFromBoardLayout(string[] boardLayoutString)
        {
            if (this.State != ae.GameState.Null)
                throw new InvalidOperationException("Can only initialize an unplayed and uninitialized game!");

            ///////////////////////////////////////////////////////////////////
            // Initialize the board...

            this.State = ae.GameState.Initialization;
            List<Move> allMoves = new List<Move>(ru.NumPlayers * ru.NumPieces);
            Player iWhoseTurn = null;
            int iTurnNumber = -1;

            bool bReadCurTurn = false;
            string sCurTurnMoves = null;
            int RankIndex = 0;
            for (int i = 0; i < boardLayoutString.Length && RankIndex < Board.NumRanks; ++i)
            {
                if (!bReadCurTurn)
                {
                    Match mTurn = ae.rexTurn.Match(boardLayoutString[i]);
                    if (mTurn.Success)
                    {
                        char playerColor = mTurn.Groups["pl"].Value[0];
                        iTurnNumber = int.Parse(mTurn.Groups["t"].Value);
                        iWhoseTurn = GetPlayer(Player.GetPlayerColor(playerColor));
                        sCurTurnMoves = mTurn.Groups["m"].Value;
                        bReadCurTurn = true;
                        continue;
                    }
                }

                Match mPosFileLine = ae.rexPosFileLine.Match(boardLayoutString[i]);
                if (mPosFileLine.Success && RankIndex < Board.NumRanks)
                {
                    int initRankIndex = Board.MaxRankIndex - RankIndex;
                    Group gPosFileSquares = mPosFileLine.Groups["s"];
                    for (int FileIndex = 0; FileIndex < Board.NumFiles; ++FileIndex)
                    {
                        char abbreviation = gPosFileSquares.Captures[FileIndex].Value[0];
                        ae.PlayerColor playerColor;
                        ae.PieceType pieceType;
                        if (Piece.GetInfo(abbreviation, out playerColor, out pieceType))
                        {
                            Move move = new Move(playerColor, playerColor, pieceType, FileIndex, initRankIndex, ae.Action.Place);
                            allMoves.Add(move);
                            //this.MakeMove(move);
                        }

                    }
                    RankIndex += 1;
                }
            }

            if (!bReadCurTurn || RankIndex < Board.NumRanks)
                throw new ArgumentException("The board layout string was not in the correct format.", "boardLayoutString");

            if (iTurnNumber == 1 || iTurnNumber == 2 && iWhoseTurn.Color == (ae.PlayerColor)0)
            {
                // Board layout string represents initial positions. Separate the Turns by color.
                for (int i = 0; i < ru.NumPlayers; ++i)
                {
                    ae.PlayerColor playerColor = (ae.PlayerColor)i;
                    Player player = this.GetPlayer(playerColor);
                    switch (playerColor)
                    {
                        case ae.PlayerColor.Gold:
                            this.State = ae.GameState.GoldSetup;
                            break;
                        case ae.PlayerColor.Silver:
                            this.State = ae.GameState.SilverSetup;
                            break;
                        default:
                            throw new ArgumentOutOfRangeException("playerColor");
                    }
                    this.WhoseTurn = player;
                    this.TurnMoveIndex = 0;
                    this.Turns.Add(new TurnRecord(this.TurnNumber, player, ru.NumPieces * ru.NumPlayers));
                    player.LastBoardPosition = new string(this.Board.ToCharArray());

                    List<Move> playerMoves = allMoves.FindAll(delegate(Move move) { return move.PlayerColor == playerColor; });
                    foreach (Move move in playerMoves)
                    {
                        this.MakeMove(move);
                    }
                }
            }
            else
            {
                this.Turns.Add(new TurnRecord(0, null, ru.NumPieces * ru.NumPlayers));
                foreach (Move move in allMoves)
                {
                    this.MakeMove(move);
                }
            }

            this.WhoseTurn = iWhoseTurn;
            this.TurnNumber = iTurnNumber;

            //Console.WriteLine(this.Representation);

            ///////////////////////////////////////////////////////////////////
            // Undo the moves for this turn...

            List<Move> moves = Move.GetMoves(this.WhoseTurn.Color, sCurTurnMoves);
            List<Move> unmoves = Move.GetUndoMoves(moves);

            this.CheatingInternal = true;
            this.TurnMoveIndex = 0;

            foreach (Move unmove in unmoves)
            {
                MakeMove(unmove);
            }

            this.CheatingInternal = false;

            string boardLayout = new string(this.Board.ToCharArray());
            this.WhoseTurn.LastBoardPosition = boardLayout;
            this.SetBoardLayoutRepeatCount(this.WhoseTurn.Color, boardLayout, 1);

            //Console.WriteLine(this.Representation);

            ///////////////////////////////////////////////////////////////////
            // Redo the moves for this turn...

            this.TurnMoveIndex = 0;
            this.State = this.WhoseTurn.Color == ae.PlayerColor.Gold ? ae.GameState.GoldsTurn : ae.GameState.SilversTurn;
            this.Turns.Add(new TurnRecord(this.TurnNumber, this.WhoseTurn, ru.MovesPerTurn));

            foreach (Move move in moves)
            {
                if (move.Action != ae.Action.Remove)
                    MakeMove(move);
            }

            //Console.WriteLine(this.Representation);

            return true;
        }
        #endregion Initialize

        #region PlayEntireTurn
        public bool PlayEntireTurn(Turn turn)
        {
            if (turn == null)
                return false;

            if (turn.PlayerColor != this.WhoseTurn.Color)
            {
                if (this.TurnMoveIndex != 0)
                    this.Advance();
                else
                    return false;
            }

            if (turn.TurnNumber != this.TurnNumber)
                return false;

            foreach (Move move in turn)
            {
                if (move.Action != ae.Action.Remove)
                    MakeMove(move);
            }

            if (this.TurnMoveIndex != 0)
                this.Advance();

            return true;
        }

        public bool PlayEntireTurn(string notationLine)
        {
            return this.PlayEntireTurn(Turn.GetTurn(notationLine));
        }
        #endregion PlayEntireTurn

        #region Move
        public List<MoveRecord> UndoPrevMove()
        {
            MoveRecord prevMove = this.PrevMove;
            if (prevMove == null)
                throw new InvalidOperationException("Call Retreat() to go back a turn first.");

            List<MoveRecord> undoMoves = prevMove.GetUndoMoves();

            this.CheatingInternal = true;

            this.CurTurn.RemoveAt(this.CurTurn.Count - 1);  // Remove the move being undone.

            foreach (MoveRecord undomove in undoMoves)
                MakeMove(undomove);

            MoveRecord lastUndoMove = undoMoves.Count == 0 ? null : undoMoves[undoMoves.Count - 1];
            if (lastUndoMove != null)
            {
                // It's easier to do Remove(Move) than to figure out how many to remove.
                foreach (MoveRecord undomove in undoMoves)
                    this.CurTurn.Remove(undomove);

                this.Tick = prevMove.Tick;
                this.TurnMoveIndex = prevMove.TurnMoveIndex;
                this.Board.Generation += 1;
            }

            this.CheatingInternal = false;
            return undoMoves;
        }

        public void MakeCheatMove(Player player, char pieceType, string from, string to)
        {
            this.CheatingInternal = true;

            Square sqFrom = this.Board.GetSquare(from);

            Piece piece = sqFrom.Piece;
            if (piece.Abbreviation != pieceType)
                throw new ArgumentException("pieceType");

            Square sqTo = this.Board.GetSquare(to);

            MakeMove(player, piece, sqFrom, sqTo);

            this.CheatingInternal = false;
        }

        public void MakeCheatMoveAny(Player player, char cPieceType, string to)
        {
            this.CheatingInternal = true;
            ae.PlayerColor playerColor;
            ae.PieceType pieceType;

            Piece.GetInfo(cPieceType, out playerColor, out pieceType);
            Piece piece = this.GetFreePieceForSetup(playerColor, pieceType);
            Square sqFrom = piece.Square;
            Square sqTo = this.Board.GetSquare(to);

            MakeMove(player, piece, sqFrom, sqTo);

            this.CheatingInternal = false;
        }

        public TurnRecord GetBeginningOfTakebacks()
        {
            TurnRecord t = null;
            int iTakeBacks = 0;
            for (int i = this.Turns.Count - 1; i >= 0; --i)
            {
                t = this.Turns[i];
                if (t == null || t.Count == 0)
                    continue;
                if (t[0].Action == ae.Action.Takeback)
                    ++iTakeBacks;
                else if (--iTakeBacks <= 0)
                    break;
            }
            return t;
        }

        protected void MovePiece(MoveRecord move)
        {
            move.Piece.Square = move.To;
            this.Board.Generation += 1;
        }

        protected void MovePieceShadow(MoveRecord move)
        {
            move.Piece.Shadow.Square = move.To == null ? null : move.To.Shadow;
            (move.From ?? move.To).Board.Generation += 1;
        }

        protected void UndoMovePieceShadow(MoveRecord move)
        {
            move.Piece.Square = move.From == null ? null : move.From;
            (move.From ?? move.To).Board.Generation -= 1;
        }

        public void MakeMove(MoveRecord move)
        {
            ae.Action action = ae.Action.Null;
            ae.InvalidMove invalidMoveReason = ae.InvalidMove.Null;

            if (move.Action == ae.Action.Takeback)
            {
                TurnRecord t = GetBeginningOfTakebacks();

                if (t != null)
                {
                    // TODO: Validate takeback logic for repeated board positions.
                    // TODO: Decrement dicPreviousBoardLayoutsPerPlayer the appropriate number of times when taking back.
                    // TODO: Set Player.LastBoardPosition when taking back.
                    if (this.CurTurn.Count == 0)
                    {
                        string boardLayout = new string(this.Board.ToCharArray());
                        int count = this.GetBoardLayoutRepeatCount(t.Player.Color, boardLayout);
                        if (count != 0)
                            this.SetBoardLayoutRepeatCount(t.Player.Color, boardLayout, --count);
                    }

                    List<MoveRecord> unmoves = t.GetUndoMoves();
                    this.CheatingInternal = true;

                    this.CurTurn.Add(move);
                    this.WhoseTurn = t.Player;
                    this.TurnNumber = t.TurnNumber;

                    this.Turns.Add(new TurnRecord(this.TurnNumber, this.WhoseTurn, unmoves.Count));
                    foreach (MoveRecord unmove in unmoves)
                        MakeMove(unmove);
                    this.Turns.RemoveAt(this.Turns.Count - 1);

                    this.TurnMoveIndex = ru.MovesPerTurn;
                    this.Board.Generation += 1;

                    this.CheatingInternal = false;
                    this.SwitchTurn(t.Player, false);
                }
                return;
            }

            invalidMoveReason = IsLegalMove(move, out action);
            move.Apply(action, this.Tick, this.TurnNumber, this.TurnMoveIndex);

            if (invalidMoveReason != ae.InvalidMove.Null)
                throw InvalidMoveException.MakeInvalidMoveException(move, action, invalidMoveReason);

            MovePiece(move);

            if (move.Action == ae.Action.PulledByOther)
            {
                MoveRecord prevMove = this.PrevMove;
                if (prevMove != null && prevMove.Player.Color == move.Player.Color)
                    prevMove.Action = ae.Action.PullOther;
            }

            // NOTE: Removal moves will be generated automatically by the CheckTrap() call, below. They should be ignored when fed to MakeMove().
            if (move.Removed)
                return;

            // Record move and increment the TurnMoveIndex.
            // Don't bother switching turns, let the user do that manually (allow undos until then).
            this.CurTurn.Add(move);
            this.Tick += 1;
            this.TurnMoveIndex += 1;

            if (!this.CheatingInternal)
            {
                CheckTrap(move, move.From);
                CheckTrap(move, move.To);
            }
        }

        public void MakeMove(Player player, Piece piece, Square sqFrom, Square sqTo)
        {
            MakeMove(new MoveRecord(player, piece, sqFrom, sqTo));
        }

        public void MakeMove(Player player, Piece piece, Square sqFrom, ae.Direction direction)
        {
            MakeMove(player, piece, sqFrom, sqFrom.GetSquare(direction));
        }

        public void MakeMove(Move move)
        {
            MakeMove(new MoveRecord(this, move));
        }

        public void MakeMove(ae.PlayerColor playerColor, string notation)
        {
            MakeMove(new Move(playerColor, notation));
        }

        public void MakeMove(Player player, string FileRank, ae.Direction direction)
        {
            Square sqFrom = this.Board.GetSquare(FileRank);
            MakeMove(new MoveRecord(player, sqFrom.Piece, sqFrom, sqFrom.GetSquare(direction)));
        }

        public void MakeMove(Player player, char File, int RankNumber, ae.Direction direction)
        {
            Square sqFrom = this.Board.GetSquare(File, RankNumber);
            MakeMove(new MoveRecord(player, sqFrom.Piece, sqFrom, sqFrom.GetSquare(direction)));
        }

        public void MakeMove(Player player, int FileIndex, int RankIndex, ae.Direction direction)
        {
            Square sqFrom = this.Board.GetSquare(FileIndex, RankIndex);
            MakeMove(new MoveRecord(player, sqFrom.Piece, sqFrom, sqFrom.GetSquare(direction)));
        }
        #endregion Move

        #region Trap
        protected int CheckTrap(MoveRecord move, Square square)
        {
            if (square == null)
                return 0;

            int numRemoved = 0;

            numRemoved += TrySpringTrap(move, square);
            numRemoved += TrySpringTrap(move, square.SquareNorth);
            numRemoved += TrySpringTrap(move, square.SquareEast);
            numRemoved += TrySpringTrap(move, square.SquareSouth);
            numRemoved += TrySpringTrap(move, square.SquareWest);

            return numRemoved;
        }

        protected int TrySpringTrap(MoveRecord move, Square sqTrap)
        {
            if (sqTrap == null || !sqTrap.IsTrap || sqTrap.Piece == null || sqTrap.Piece.Allies != ae.DirFlag.Null)
                return 0;

            MoveRecord other = new MoveRecord(move.Player, sqTrap.Piece, sqTrap, null);
            other.Apply(ae.Action.Remove, this.Tick, this.TurnMoveIndex, this.TurnMoveIndex);

            MovePiece(other);
            move.AddIncidentalMove(other);

            return 1;
        }
        #endregion Trap

        #region ToString
        public override string ToString()
        {
            int rankLabelWidth = 1 + (int)Math.Log10(Board.MaxRankIndex);
            string rankLabelFormat = "{0," + rankLabelWidth + "}|";
            string horzBorder = new string(' ', rankLabelWidth) + "+" + new string('-', Board.NumFiles * 2 + 1) + "+";
            StringBuilder sb = new StringBuilder(((Board.NumFiles * 2) + 6) * (Board.NumRanks + 4));
            string movesThisTurn = this.MovesThisTurn;
            sb.AppendFormat("{0}{1}{2}{3}\n", this.TurnNumber, this.WhoseTurn.Abbreviation, (movesThisTurn.Length == 0 ? "" : " "), movesThisTurn);
            sb.AppendLine(horzBorder);
            for (int RankIndex = 0; RankIndex < Board.NumRanks; ++RankIndex)
            {
                sb.AppendFormat(rankLabelFormat, Board.NumRanks - RankIndex);
                for (int FileIndex = 0; FileIndex < Board.NumFiles; ++FileIndex)
                {
                    sb.AppendFormat(" {0}", this.Board.GetSquare(FileIndex, Board.MaxRankIndex - RankIndex).Abbreviation);
                }
                sb.AppendLine(" |");
            }
            sb.AppendLine(horzBorder);
            sb.Append(' ', rankLabelWidth + 1);
            for (int FileIndex = 0; FileIndex < Board.NumFiles; ++FileIndex)
            {
                sb.AppendFormat(" {0}", Board.FileNames[FileIndex]);
            }
            sb.AppendLine();
            return sb.ToString();
        }

        public string GetLegalMoveString()
        {
            StringBuilder sb = new StringBuilder();

            int powRows = 3 * Board.NumFiles;
            int powCols = 3 * Board.NumRanks;

            char[,] pow = new char[powCols, powRows];
            for (int pri = 0; pri < powRows; ++pri)
            {
                for (int pci = 0; pci < powCols; ++pci)
                {
                    pow[pci, pri] = ' ';
                }
            }

            for (int RankIndex = 0; RankIndex < Board.NumRanks; ++RankIndex)
            {
                for (int FileIndex = 0; FileIndex < Board.NumFiles; ++FileIndex)
                {
                    Square sqFrom = this.Board.GetSquare(FileIndex, Board.MaxRankIndex - RankIndex);
                    Piece pc = sqFrom.Piece;

                    if (pc != null)
                    {
                        pow[FileIndex * 3 + 1, RankIndex * 3 + 1] = pc.Abbreviation;

                        Square sqTo = null;

                        sqTo = sqFrom.SquareNorth;
                        if (sqTo != null)
                        {
                            ae.Action action = ae.Action.Null;
                            ae.InvalidMove invalidMoveReason = ae.InvalidMove.Null;
                            MoveRecord move = new MoveRecord(this.WhoseTurn, pc, sqFrom, sqTo);
                            invalidMoveReason = IsLegalMove(move, out action);
                            if (invalidMoveReason == ae.InvalidMove.Null)
                                pow[FileIndex * 3 + 1, RankIndex * 3] = '^';
                        }

                        sqTo = sqFrom.SquareEast;
                        if (sqTo != null)
                        {
                            ae.Action action = ae.Action.Null;
                            ae.InvalidMove invalidMoveReason = ae.InvalidMove.Null;
                            MoveRecord move = new MoveRecord(this.WhoseTurn, pc, sqFrom, sqTo);
                            invalidMoveReason = IsLegalMove(move, out action);
                            if (invalidMoveReason == ae.InvalidMove.Null)
                                pow[FileIndex * 3 + 2, RankIndex * 3 + 1] = '>';
                        }

                        sqTo = sqFrom.SquareSouth;
                        if (sqTo != null)
                        {
                            ae.Action action = ae.Action.Null;
                            ae.InvalidMove invalidMoveReason = ae.InvalidMove.Null;
                            MoveRecord move = new MoveRecord(this.WhoseTurn, pc, sqFrom, sqTo);
                            invalidMoveReason = IsLegalMove(move, out action);
                            if (invalidMoveReason == ae.InvalidMove.Null)
                                pow[FileIndex * 3 + 1, RankIndex * 3 + 2] = 'v';
                        }

                        sqTo = sqFrom.SquareWest;
                        if (sqTo != null)
                        {
                            ae.Action action = ae.Action.Null;
                            ae.InvalidMove invalidMoveReason = ae.InvalidMove.Null;
                            MoveRecord move = new MoveRecord(this.WhoseTurn, pc, sqFrom, sqTo);
                            invalidMoveReason = IsLegalMove(move, out action);
                            if (invalidMoveReason == ae.InvalidMove.Null)
                                pow[FileIndex * 3, RankIndex * 3 + 1] = '<';
                        }
                    }
                }
            }

            for (int pri = 0; pri < powRows; ++pri)
            {
                for (int pci = 0; pci < powCols; ++pci)
                {
                    sb.Append(pow[pci, pri]);
                }
                sb.AppendLine();
            }

            return sb.ToString();
        }

        public string Representation { get { return this.ToString(); } }

        public string MovesThisTurn
        {
            get
            {
                TurnRecord t = this.CurTurn;
                if (t == null)
                    return string.Empty;
                else
                    return t.ToString();
            }
        }
        #endregion ToString

        #region GetLegalMoves
        public List<MoveRecord> GetLegalMoves()
        {
            List<MoveRecord> moves = new List<MoveRecord>(1024);

            AddLegalMoves(moves, this.Gold);
            AddLegalMoves(moves, this.Silver);

            return moves;
        }

        public void AddLegalMoves(List<MoveRecord> moves, Piece piece)
        {
            if (piece == null)
                return;

            Square sqFrom = piece.Square;
            if (sqFrom == null)
                return;

            Square sqTo = null;

            sqTo = sqFrom.SquareNorth;
            if (sqTo != null)
            {
                ae.Action action = ae.Action.Null;
                ae.InvalidMove invalidMoveReason = ae.InvalidMove.Null;
                MoveRecord move = new MoveRecord(this.WhoseTurn, piece, sqFrom, sqTo);
                invalidMoveReason = IsLegalMove(move, out action);
                if (invalidMoveReason == ae.InvalidMove.Null)
                    moves.Add(move);
            }

            sqTo = sqFrom.SquareEast;
            if (sqTo != null)
            {
                ae.Action action = ae.Action.Null;
                ae.InvalidMove invalidMoveReason = ae.InvalidMove.Null;
                MoveRecord move = new MoveRecord(this.WhoseTurn, piece, sqFrom, sqTo);
                invalidMoveReason = IsLegalMove(move, out action);
                if (invalidMoveReason == ae.InvalidMove.Null)
                    moves.Add(move);
            }

            sqTo = sqFrom.SquareSouth;
            if (sqTo != null)
            {
                ae.Action action = ae.Action.Null;
                ae.InvalidMove invalidMoveReason = ae.InvalidMove.Null;
                MoveRecord move = new MoveRecord(this.WhoseTurn, piece, sqFrom, sqTo);
                invalidMoveReason = IsLegalMove(move, out action);
                if (invalidMoveReason == ae.InvalidMove.Null)
                    moves.Add(move);
            }

            sqTo = sqFrom.SquareWest;
            if (sqTo != null)
            {
                ae.Action action = ae.Action.Null;
                ae.InvalidMove invalidMoveReason = ae.InvalidMove.Null;
                MoveRecord move = new MoveRecord(this.WhoseTurn, piece, sqFrom, sqTo);
                invalidMoveReason = IsLegalMove(move, out action);
                if (invalidMoveReason == ae.InvalidMove.Null)
                    moves.Add(move);
            }
        }

        protected void AddLegalMoves(List<MoveRecord> moves, Player player)
        {
            foreach (Piece piece in player.Pieces)
            {
                AddLegalMoves(moves, piece);
            }
        }

        public void FillLegalMoves(ae.DirFlag[,] movedirs, out int totalNumberOfLegalMoves)
        {
            totalNumberOfLegalMoves = 0;
            for (int RankIndex = 0; RankIndex < Board.NumRanks; ++RankIndex)
            {
                for (int FileIndex = 0; FileIndex < Board.NumFiles; ++FileIndex)
                {
                    Square sqFrom = this.Board.GetSquare(FileIndex, RankIndex);
                    Piece pc = sqFrom.Piece;
                    ae.DirFlag movedir = ae.DirFlag.Null;

                    if (pc != null)
                    {
                        Square sqTo = null;

                        sqTo = sqFrom.SquareNorth;
                        if (sqTo != null)
                        {
                            ae.Action action = ae.Action.Null;
                            ae.InvalidMove invalidMoveReason = ae.InvalidMove.Null;
                            MoveRecord move = new MoveRecord(this.WhoseTurn, pc, sqFrom, sqTo);
                            invalidMoveReason = IsLegalMove(move, out action);
                            if (invalidMoveReason == ae.InvalidMove.Null)
                            {
                                movedir |= ae.DirFlag.North;
                                ++totalNumberOfLegalMoves;
                            }
                        }

                        sqTo = sqFrom.SquareEast;
                        if (sqTo != null)
                        {
                            ae.Action action = ae.Action.Null;
                            ae.InvalidMove invalidMoveReason = ae.InvalidMove.Null;
                            MoveRecord move = new MoveRecord(this.WhoseTurn, pc, sqFrom, sqTo);
                            invalidMoveReason = IsLegalMove(move, out action);
                            if (invalidMoveReason == ae.InvalidMove.Null)
                            {
                                movedir |= ae.DirFlag.East;
                                ++totalNumberOfLegalMoves;
                            }
                        }

                        sqTo = sqFrom.SquareSouth;
                        if (sqTo != null)
                        {
                            ae.Action action = ae.Action.Null;
                            ae.InvalidMove invalidMoveReason = ae.InvalidMove.Null;
                            MoveRecord move = new MoveRecord(this.WhoseTurn, pc, sqFrom, sqTo);
                            invalidMoveReason = IsLegalMove(move, out action);
                            if (invalidMoveReason == ae.InvalidMove.Null)
                            {
                                movedir |= ae.DirFlag.South;
                                ++totalNumberOfLegalMoves;
                            }
                        }

                        sqTo = sqFrom.SquareWest;
                        if (sqTo != null)
                        {
                            ae.Action action = ae.Action.Null;
                            ae.InvalidMove invalidMoveReason = ae.InvalidMove.Null;
                            MoveRecord move = new MoveRecord(this.WhoseTurn, pc, sqFrom, sqTo);
                            invalidMoveReason = IsLegalMove(move, out action);
                            if (invalidMoveReason == ae.InvalidMove.Null)
                            {
                                movedir |= ae.DirFlag.West;
                                ++totalNumberOfLegalMoves;
                            }
                        }
                    }
                    movedirs[FileIndex, RankIndex] = movedir;
                }
            }
        }
        #endregion GetLegalMoves
    }
}
