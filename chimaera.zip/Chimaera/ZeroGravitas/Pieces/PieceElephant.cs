﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZeroGravitas
{
    public class PieceElephant : Piece
    {
        public const char AbbreviationGold = lng.AbvGoldElephant;
        public const char AbbreviationSilver = lng.AbvSilverElephant;

        #region IPiece Members
        public override int Value { get { return 6; } }

        public override char Abbreviation { get { return this.Player.Color == ae.PlayerColor.Gold ? AbbreviationGold : AbbreviationSilver; } }

        public override ae.PieceType PieceType { get { return ae.PieceType.Elephant; } }

        public override int ImageIndex { get { return this.Player.Color == ae.PlayerColor.Gold ? 10 : 11; } }
        #endregion IPiece Members

        public PieceElephant()
        { }

        public PieceElephant(Player player)
            : base(player)
        { }
    }
}
