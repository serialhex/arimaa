﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZeroGravitas
{
    public class PieceCat : Piece
    {
        public const char AbbreviationGold = lng.AbvGoldCat;
        public const char AbbreviationSilver = lng.AbvSilverCat;

        #region IPiece Members
        public override int Value { get { return 2; } }

        public override char Abbreviation { get { return this.Player.Color == ae.PlayerColor.Gold ? AbbreviationGold : AbbreviationSilver; } }

        public override ae.PieceType PieceType { get { return ae.PieceType.Cat; } }

        public override int ImageIndex { get { return this.Player.Color == ae.PlayerColor.Gold ? 2 : 3; } }
        #endregion IPiece Members

        public PieceCat()
        { }

        public PieceCat(Player player)
            : base(player)
        { }
    }
}
