﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZeroGravitas
{
    public abstract class Piece : IPiece
    {
        #region IPiece Members
        public Piece Base { get { return this; } }

        public IPiece IBase { get { return this; } }

        protected internal Piece Shadow { get; set; }
        protected internal Piece ShadowOf { get; set; }

        public ae.PlayerColor Color { get { return this.Player.Color; } }

        public Player Player { get; internal protected set; }

        public Square StartingSquare { get; internal protected set; }

        public bool HasMoved { get; protected set; }

        public bool IsInPlay { get; protected set; }

        public int NumMoves { get; protected set; }

        public int LastMoveOn { get; protected set; }

        public virtual int Value { get { return -1; } }

        public virtual bool CanPush(Piece other) { return this.Value > other.Value; }

        public virtual bool CanPull(Piece other) { return this.Value > other.Value; }

        public virtual bool CanFreeze(Piece other) { return this.Value > other.Value; }

        public virtual ae.Movement Movement { get { return ae.Movement.All; } }

        public virtual char Abbreviation { get { throw new NotImplementedException(); } }

        public virtual ae.PieceType PieceType { get { return ae.PieceType.Null; } }

        public virtual int ImageIndex { get { return -1; } }

        protected Square mSquare = null;
        public Square Square
        {
            get { return mSquare; }
            protected internal set
            {
                if (mSquare == value)
                    return;

                if (mSquare != null && mSquare.Piece == this)
                    mSquare.setPieceSimple(null);

                if (value != null && value.Piece != this)
                    value.setPieceSimple(this);

                mSquare = value;
            }
        }

        protected internal void setSquareSimple(Square sq)
        {
            mSquare = sq;
        }

        public bool IsFrozen
        {
            get
            {
                return this.Freezers != ae.DirFlag.Null && this.Allies == ae.DirFlag.Null;
            }
        }

        public bool CanBePulled
        {
            get
            {
                return this.Pullers != ae.DirFlag.Null;
            }
        }

        public bool CanBePushed
        {
            get
            {
                return this.Pushers != ae.DirFlag.Null && this.Vacancies != ae.DirFlag.Null;
            }
        }

        public ae.DirFlag Vacancies
        {
            get
            {
                if (lastSpyGeneration != this.Square.Board.Generation)
                    refreshSpy();
                return mVacancies;
            }
        }

        public ae.DirFlag Allies
        {
            get
            {
                if (lastSpyGeneration != this.Square.Board.Generation)
                    refreshSpy();
                return mAllies;
            }
        }

        public ae.DirFlag Freezers
        {
            get
            {
                if (lastSpyGeneration != this.Square.Board.Generation)
                    refreshSpy();
                return mFreezers;
            }
        }

        public ae.DirFlag Pullers
        {
            get
            {
                if (lastSpyGeneration != this.Square.Board.Generation)
                    refreshSpy();
                return mPullers;
            }
        }

        public ae.DirFlag Pushers
        {
            get
            {
                if (lastSpyGeneration != this.Square.Board.Generation)
                    refreshSpy();
                return mPushers;
            }
        }
        #endregion IPiece Members

        #region Member Variables
        protected int lastSpyGeneration = -1;
        protected ae.DirFlag mVacancies;
        protected ae.DirFlag mAllies;
        protected ae.DirFlag mFreezers;
        protected ae.DirFlag mPullers;
        protected ae.DirFlag mPushers;
        #endregion Member Variables

        #region Constructors
        public Piece()
        { }

        public Piece(Player player)
        {
            this.Player = player;
        }
        #endregion Constructors

        protected void refreshSpy()
        {
            this.lastSpyGeneration = this.Square.Board.Generation;
            mVacancies = ae.DirFlag.Null;
            mAllies = ae.DirFlag.Null;
            mFreezers = ae.DirFlag.Null;
            mPullers = ae.DirFlag.Null;
            mPushers = ae.DirFlag.Null;
            Square sq = null;

            sq = this.Square.SquareNorth;
            if (sq != null)
            {
                if (sq.Piece == null)
                    mVacancies |= ae.DirFlag.North;
                else if (sq.Piece.Player.Color == this.Player.Color)
                    mAllies |= ae.DirFlag.North;
                else
                {
                    if (sq.Piece.CanFreeze(this))
                        mFreezers |= ae.DirFlag.North;
                    if (sq.Piece.CanPull(this))
                        mPullers |= ae.DirFlag.North;
                    if (sq.Piece.CanPush(this))
                        mPushers |= ae.DirFlag.North;
                }
            }

            sq = this.Square.SquareEast;
            if (sq != null)
            {
                if (sq.Piece == null)
                    mVacancies |= ae.DirFlag.East;
                else if (sq.Piece.Player.Color == this.Player.Color)
                    mAllies |= ae.DirFlag.East;
                else
                {
                    if (sq.Piece.CanFreeze(this))
                        mFreezers |= ae.DirFlag.East;
                    if (sq.Piece.CanPull(this))
                        mPullers |= ae.DirFlag.East;
                    if (sq.Piece.CanPush(this))
                        mPushers |= ae.DirFlag.East;
                }
            }

            sq = this.Square.SquareSouth;
            if (sq != null)
            {
                if (sq.Piece == null)
                    mVacancies |= ae.DirFlag.South;
                else if (sq.Piece.Player.Color == this.Player.Color)
                    mAllies |= ae.DirFlag.South;
                else
                {
                    if (sq.Piece.CanFreeze(this))
                        mFreezers |= ae.DirFlag.South;
                    if (sq.Piece.CanPull(this))
                        mPullers |= ae.DirFlag.South;
                    if (sq.Piece.CanPush(this))
                        mPushers |= ae.DirFlag.South;
                }
            }

            sq = this.Square.SquareWest;
            if (sq != null)
            {
                if (sq.Piece == null)
                    mVacancies |= ae.DirFlag.West;
                else if (sq.Piece.Player.Color == this.Player.Color)
                    mAllies |= ae.DirFlag.West;
                else
                {
                    if (sq.Piece.CanFreeze(this))
                        mFreezers |= ae.DirFlag.West;
                    if (sq.Piece.CanPull(this))
                        mPullers |= ae.DirFlag.West;
                    if (sq.Piece.CanPush(this))
                        mPushers |= ae.DirFlag.West;
                }
            }
        }

        #region Static Helper Functions
        public static ae.PieceType GetPieceType(char abbreviation)
        {
            switch (abbreviation)
            {
                case PieceElephant.AbbreviationGold:
                case PieceElephant.AbbreviationSilver:
                    return ae.PieceType.Elephant;
                case PieceCamel.AbbreviationGold:
                case PieceCamel.AbbreviationSilver:
                    return ae.PieceType.Camel;
                case PieceHorse.AbbreviationGold:
                case PieceHorse.AbbreviationSilver:
                    return ae.PieceType.Horse;
                case PieceDog.AbbreviationGold:
                case PieceDog.AbbreviationSilver:
                    return ae.PieceType.Dog;
                case PieceCat.AbbreviationGold:
                case PieceCat.AbbreviationSilver:
                    return ae.PieceType.Cat;
                case PieceRabbit.AbbreviationGold:
                case PieceRabbit.AbbreviationSilver:
                    return ae.PieceType.Rabbit;
                default:
                    return ae.PieceType.Null;
            }
        }

        public static bool GetInfo(char abbreviation, out ae.PlayerColor playerColor, out ae.PieceType pieceType)
        {
            switch (abbreviation)
            {
                case PieceElephant.AbbreviationGold:
                    playerColor = ae.PlayerColor.Gold;
                    pieceType = ae.PieceType.Elephant;
                    break;
                case PieceElephant.AbbreviationSilver:
                    playerColor = ae.PlayerColor.Silver;
                    pieceType = ae.PieceType.Elephant;
                    break;
                case PieceCamel.AbbreviationGold:
                    playerColor = ae.PlayerColor.Gold;
                    pieceType = ae.PieceType.Camel;
                    break;
                case PieceCamel.AbbreviationSilver:
                    playerColor = ae.PlayerColor.Silver;
                    pieceType = ae.PieceType.Camel;
                    break;
                case PieceHorse.AbbreviationGold:
                    playerColor = ae.PlayerColor.Gold;
                    pieceType = ae.PieceType.Horse;
                    break;
                case PieceHorse.AbbreviationSilver:
                    playerColor = ae.PlayerColor.Silver;
                    pieceType = ae.PieceType.Horse;
                    break;
                case PieceDog.AbbreviationGold:
                    playerColor = ae.PlayerColor.Gold;
                    pieceType = ae.PieceType.Dog;
                    break;
                case PieceDog.AbbreviationSilver:
                    playerColor = ae.PlayerColor.Silver;
                    pieceType = ae.PieceType.Dog;
                    break;
                case PieceCat.AbbreviationGold:
                    playerColor = ae.PlayerColor.Gold;
                    pieceType = ae.PieceType.Cat;
                    break;
                case PieceCat.AbbreviationSilver:
                    playerColor = ae.PlayerColor.Silver;
                    pieceType = ae.PieceType.Cat;
                    break;
                case PieceRabbit.AbbreviationGold:
                    playerColor = ae.PlayerColor.Gold;
                    pieceType = ae.PieceType.Rabbit;
                    break;
                case PieceRabbit.AbbreviationSilver:
                    playerColor = ae.PlayerColor.Silver;
                    pieceType = ae.PieceType.Rabbit;
                    break;
                default:
                    playerColor = ae.PlayerColor.Gold;
                    pieceType = ae.PieceType.Null;
                    return false;
            }
            return true;
        }

        public static char GetPieceChar(ae.PlayerColor playerColor, ae.PieceType pieceType)
        {
            switch (playerColor)
            {
                case ae.PlayerColor.Gold:
                    switch (pieceType)
                    {
                        case ae.PieceType.Elephant:
                            return PieceElephant.AbbreviationGold;
                        case ae.PieceType.Camel:
                            return PieceCamel.AbbreviationGold;
                        case ae.PieceType.Horse:
                            return PieceHorse.AbbreviationGold;
                        case ae.PieceType.Dog:
                            return PieceDog.AbbreviationGold;
                        case ae.PieceType.Cat:
                            return PieceCat.AbbreviationGold;
                        case ae.PieceType.Rabbit:
                            return PieceRabbit.AbbreviationGold;
                        default:
                            return lng.UnknownPieceType;
                    }
                case ae.PlayerColor.Silver:
                    switch (pieceType)
                    {
                        case ae.PieceType.Elephant:
                            return PieceElephant.AbbreviationSilver;
                        case ae.PieceType.Camel:
                            return PieceCamel.AbbreviationSilver;
                        case ae.PieceType.Horse:
                            return PieceHorse.AbbreviationSilver;
                        case ae.PieceType.Dog:
                            return PieceDog.AbbreviationSilver;
                        case ae.PieceType.Cat:
                            return PieceCat.AbbreviationSilver;
                        case ae.PieceType.Rabbit:
                            return PieceRabbit.AbbreviationSilver;
                        default:
                            return lng.UnknownPieceType;
                    }
                default:
                    return lng.UnknownPieceType;
            }
        }
        #endregion Static Helper Functions
    }
}
