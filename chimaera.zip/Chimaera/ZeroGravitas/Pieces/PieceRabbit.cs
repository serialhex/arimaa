﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZeroGravitas
{
    public class PieceRabbit : Piece
    {
        public const char AbbreviationGold = lng.AbvGoldRabbit;
        public const char AbbreviationSilver = lng.AbvSilverRabbit;

        #region IPiece Members
        public override int Value { get { return 1; } }

        public override ae.Movement Movement { get { return ae.Movement.Forward | ae.Movement.Right | ae.Movement.Left; } }

        public override char Abbreviation { get { return this.Player.Color == ae.PlayerColor.Gold ? AbbreviationGold : AbbreviationSilver; } }

        public override ae.PieceType PieceType { get { return ae.PieceType.Rabbit; } }

        public override int ImageIndex { get { return this.Player.Color == ae.PlayerColor.Gold ? 0 : 1; } }
        #endregion IPiece Members

        public PieceRabbit()
        { }

        public PieceRabbit(Player player)
            : base(player)
        { }
    }
}
