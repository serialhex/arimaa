﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZeroGravitas
{
    public class PieceDog : Piece
    {
        public const char AbbreviationGold = lng.AbvGoldDog;
        public const char AbbreviationSilver = lng.AbvSilverDog;

        #region IPiece Members
        public override int Value { get { return 3; } }

        public override char Abbreviation { get { return this.Player.Color == ae.PlayerColor.Gold ? AbbreviationGold : AbbreviationSilver; } }

        public override ae.PieceType PieceType { get { return ae.PieceType.Dog; } }

        public override int ImageIndex { get { return this.Player.Color == ae.PlayerColor.Gold ? 4 : 5; } }
        #endregion IPiece Members

        public PieceDog()
        { }

        public PieceDog(Player player)
            : base(player)
        { }
    }
}
