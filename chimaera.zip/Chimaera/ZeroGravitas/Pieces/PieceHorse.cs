﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZeroGravitas
{
    public class PieceHorse : Piece
    {
        public const char AbbreviationGold = lng.AbvGoldHorse;
        public const char AbbreviationSilver = lng.AbvSilverHorse;

        #region IPiece Members
        public override int Value { get { return 4; } }

        public override char Abbreviation { get { return this.Player.Color == ae.PlayerColor.Gold ? AbbreviationGold : AbbreviationSilver; } }

        public override ae.PieceType PieceType { get { return ae.PieceType.Horse; } }

        public override int ImageIndex { get { return this.Player.Color == ae.PlayerColor.Gold ? 6 : 7; } }
        #endregion IPiece Members

        public PieceHorse()
        { }

        public PieceHorse(Player player)
            : base(player)
        { }
    }
}
