﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZeroGravitas
{
    public class PieceCamel : Piece
    {
        public const char AbbreviationGold = lng.AbvGoldCamel;
        public const char AbbreviationSilver = lng.AbvSilverCamel;

        #region IPiece Members
        public override int Value { get { return 5; } }

        public override char Abbreviation { get { return this.Player.Color == ae.PlayerColor.Gold ? AbbreviationGold : AbbreviationSilver; } }

        public override ae.PieceType PieceType { get { return ae.PieceType.Camel; } }

        public override int ImageIndex { get { return this.Player.Color == ae.PlayerColor.Gold ? 8 : 9; } }
        #endregion IPiece Members

        public PieceCamel()
        { }

        public PieceCamel(Player player)
            : base(player)
        { }
    }
}
