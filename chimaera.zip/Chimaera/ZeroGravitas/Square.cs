﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZeroGravitas
{
    public class Square
    {
        protected Square() { }

        public Square(Board board, int FileIndex, int RankIndex)
        {
            this.Board = board;
            this.File = FileIndex;
            this.Rank = RankIndex;
            this.Color = (this.File % 2) == 0
                ? (this.Rank % 2) == 0 ? ae.SquareColor.Black : ae.SquareColor.White
                : (this.Rank % 2) == 0 ? ae.SquareColor.White : ae.SquareColor.Black;
        }

        public Board Board { get; protected set; }
        protected internal Square Shadow { get; set; }
        public ae.SquareColor Color { get; protected set; }
        public int Rank { get; protected set; }
        public int File { get; protected set; }
        public char FileName { get { return Board.FileNames[File]; } }
        public string RankName { get { return (Rank + 1).ToString(); } }
        public bool IsTrap { get; internal protected set; }
        public bool IsValidStartPositionGold { get; internal protected set; }
        public bool IsValidStartPositionSilver { get; internal protected set; }
        public string Name { get { return string.Concat(FileName, RankName); } }
        public Piece LastOccupant { get; protected set; }
        public int LastOccupiedAt { get; protected set; }

        public char Abbreviation
        {
            get
            {
                return this.Piece == null ? this.IsTrap ? lng.Removal : this.Color == ae.SquareColor.White ? lng.WhiteSquare : lng.BlackSquare : this.Piece.Abbreviation;
            }
        }

        protected Piece mPiece;
        public Piece Piece
        {
            get { return mPiece; }
            /*
            protected internal set
            {
                if (mPiece == value)
                    return;

                if (mPiece != null)
                {
                    if (mPiece.Square == this)
                        mPiece.setSquareSimple(null);

                    LastOccupant = mPiece;
                    if (this.Board.Game != null)
                        LastOccupiedAt = this.Board.Game.Tick;
                }

                if (value != null && value.Square != this)
                    value.setSquareSimple(this);

                mPiece = value;
            }
            */
        }

        protected internal void setPieceSimple(Piece pc)
        {
            mPiece = pc;
        }

        public Square SquareNorth { get { return this.Board.GetSquare(this.File, this.Rank + 1); } }
        public Square SquareEast { get { return this.Board.GetSquare(this.File + 1, this.Rank); } }
        public Square SquareSouth { get { return this.Board.GetSquare(this.File, this.Rank - 1); } }
        public Square SquareWest { get { return this.Board.GetSquare(this.File - 1, this.Rank); } }

        public Piece PieceNorth { get { return this.Board.GetPiece(this.File, this.Rank + 1); } }
        public Piece PieceEast { get { return this.Board.GetPiece(this.File + 1, this.Rank); } }
        public Piece PieceSouth { get { return this.Board.GetPiece(this.File, this.Rank - 1); } }
        public Piece PieceWest { get { return this.Board.GetPiece(this.File - 1, this.Rank); } }

        public bool NeighborNorth { get { return this.Rank != 0; } }
        public bool NeighborEast { get { return this.File != Board.NumFiles - 1; } }
        public bool NeighborSouth { get { return this.Rank != Board.NumRanks - 1; } }
        public bool NeighborWest { get { return this.File != 0; } }

        public bool HasNeighbor(ae.Direction direction)
        {
            switch (direction)
            {
                case ae.Direction.North:
                    return NeighborNorth;
                case ae.Direction.East:
                    return NeighborEast;
                case ae.Direction.South:
                    return NeighborSouth;
                case ae.Direction.West:
                    return NeighborWest;
                default:
                    throw new ArgumentOutOfRangeException("Unknown direction!");
            }
        }

        public Square GetSquare(ae.Direction direction)
        {
            switch (direction)
            {
                case ae.Direction.North:
                    return SquareNorth;
                case ae.Direction.East:
                    return SquareEast;
                case ae.Direction.South:
                    return SquareSouth;
                case ae.Direction.West:
                    return SquareWest;
                case ae.Direction.Null:
                    return null;
                default:
                    throw new ArgumentOutOfRangeException("Unknown direction!");
            }
        }

        public ae.Direction GetDirectionToAdjacent(Square other)
        {
            if (other == null)
                return ae.Direction.Null;

            if (this.File == other.File)
            {
                if (this.Rank == other.Rank - 1)
                    return ae.Direction.North;
                else if (this.Rank == other.Rank + 1)
                    return ae.Direction.South;
                else
                    return ae.Direction.Null;
            }
            else if (this.Rank == other.Rank)
            {
                if (this.File == other.File - 1)
                    return ae.Direction.East;
                else if (this.File == other.File + 1)
                    return ae.Direction.West;
                else
                    return ae.Direction.Null;
            }
            else
                return ae.Direction.Null;
        }

        public override string ToString()
        {
            //if (this.Shadow == null)
            //    return "-" + this.Name;
            return this.Name;
        }
    }
}
