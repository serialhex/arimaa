﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;

namespace ZeroGravitas
{
    public class GameReader : IDisposable
    {
        #region Member Variables
        public FileInfo FileInfo { get; protected set; }
        protected StreamReader FileReader { get; set; }
        protected Dictionary<string, int> mDicColumns = new Dictionary<string, int>(32);
        #endregion Member Variables

        #region Constructor
        public GameReader()
        { }

        public GameReader(FileInfo fileInfo)
        {
            this.FileInfo = fileInfo;
        }

        public GameReader(string fileName)
            : this(new FileInfo(fileName))
        { }
        #endregion Constructor

        #region Open and Initialize
        protected void Open()
        {
            if (FileReader != null)
                throw new IOException("GameReader file is already open!");

            FileReader = FileInfo.OpenText();
            string gameFileHeaderLine = FileReader.ReadLine();
            this.Initialize(gameFileHeaderLine);
        }

        public void Initialize(string gameFileHeaderLine)
        {
            string[] cols = gameFileHeaderLine.Split('\t');
            for (int i = 0; i < cols.Length; ++i)
            {
                string col = cols[i];
                mDicColumns[col] = i;
            }
        }
        #endregion Open and Initialize

        #region Column Access Helper Functions
        protected int GetColumnIndex(string columnName)
        {
            int index = 0;
            if (!mDicColumns.TryGetValue(columnName, out index))
                index = -1;
            return index;
        }

        protected bool GetIntegerField(string[] cols, string columnName, out int value)
        {
            int columnIndex = GetColumnIndex(columnName);
            if (columnIndex != -1)
                return int.TryParse(cols[columnIndex], out value);
            value = 0;
            return false;
        }

        protected bool GetStringField(string[] cols, string columnName, out string value)
        {
            int columnIndex = GetColumnIndex(columnName);
            if (columnIndex != -1)
            {
                value = cols[columnIndex];
                return true;
            }
            value = null;
            return false;
        }
        #endregion Column Access Helper Functions

        #region GetNextGame
        public bool GetNextGame(string gameFileLine, out Game game, out string[] notationLines)
        {
            if (string.IsNullOrEmpty(gameFileLine))
            {
                game = null;
                notationLines = null;
                return false;
            }
            bool success;

            string[] cols = gameFileLine.Split('\t');
            int id, wplayerid, bplayerid, wrating, brating, plycount;
            string wusername, busername, wtype, btype, result, termination, movelist;

            success = GetIntegerField(cols, "id", out id);
            if (!success)
                throw new Exception("Unable to read id");

            success = GetIntegerField(cols, "wplayerid", out wplayerid);
            if (!success)
                throw new Exception("Unable to read wplayerid");

            success = GetIntegerField(cols, "bplayerid", out bplayerid);
            if (!success)
                throw new Exception("Unable to read bplayerid");

            success = GetIntegerField(cols, "wrating", out wrating);
            if (!success)
                throw new Exception("Unable to read wrating");

            success = GetIntegerField(cols, "brating", out brating);
            if (!success)
                throw new Exception("Unable to read brating");

            success = GetIntegerField(cols, "plycount", out plycount);
            if (!success)
                throw new Exception("Unable to read plycount");

            ///////////////////////////////////////////////////////////////////
            ///////////////////////////////////////////////////////////////////
            ///////////////////////////////////////////////////////////////////

            success = GetStringField(cols, "wusername", out wusername);
            if (!success)
                throw new Exception("Unable to read wusername");

            success = GetStringField(cols, "busername", out busername);
            if (!success)
                throw new Exception("Unable to read busername");

            success = GetStringField(cols, "wtype", out wtype);
            if (!success)
                throw new Exception("Unable to read wtype");

            success = GetStringField(cols, "btype", out btype);
            if (!success)
                throw new Exception("Unable to read btype");

            success = GetStringField(cols, "result", out result);
            if (!success)
                throw new Exception("Unable to read result");

            success = GetStringField(cols, "termination", out termination);
            if (!success)
                throw new Exception("Unable to read termination");

            success = GetStringField(cols, "movelist", out movelist);
            if (!success)
                throw new Exception("Unable to read movelist");

            ///////////////////////////////////////////////////////////////////
            ///////////////////////////////////////////////////////////////////
            ///////////////////////////////////////////////////////////////////

            notationLines = movelist.Split(new string[] { @"\n" }, StringSplitOptions.None);

            game = new Game(id);

            game.Gold.Name = wusername;
            game.Gold.PlayerId = wplayerid;
            game.Gold.Rating = wrating;

            game.Silver.Name = busername;
            game.Silver.PlayerId = bplayerid;
            game.Silver.Rating = brating;

            return success;
        }

        public bool GetNextGame(out Game game, out string[] notationLines)
        {
            if (this.FileReader == null)
                this.Open();

            string gameFileLine = FileReader.ReadLine();

            return GetNextGame(gameFileLine, out game, out notationLines);
        }
        #endregion GetNextGame

        #region IDisposable Members
        public bool _disposed = false;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    if (FileReader != null)
                        FileReader.Dispose();
                }

                FileReader = null;
                _disposed = true;
            }
        }
        #endregion
    }
}
