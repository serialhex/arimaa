﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZeroGravitas
{
    public class Player
    {
        #region Properties
        public const char GoldChar = 'g';
        public const char GoldCharAlt = 'w';
        public const char SilverChar = 's';
        public const char SilverCharAlt = 'b';
        public static readonly string LegalColorChars = string.Concat(GoldChar, GoldCharAlt, SilverChar, SilverCharAlt);

        public int PlayerId { get; set; }
        public string Name { get; set; }
        public int Rating { get; set; }
        public ae.PlayerColor Color { get; protected set; }
        public char Abbreviation { get { return this.Color == ae.PlayerColor.Gold ? GoldChar : SilverChar; } }
        public ae.Intelligence Intelligence { get; set; }
        public Game Game { get; protected set; }
        public string LastBoardPosition { get; protected internal set; } // TODO: Set LastBoardPosition, and reset it when taking back a turn.

        public PieceRabbit[] Rabbits { get; protected set; }
        public PieceCat[] Cats { get; protected set; }
        public PieceDog[] Dogs { get; protected set; }
        public PieceHorse[] Horses { get; protected set; }
        public PieceCamel[] Camels { get; protected set; }
        public PieceElephant[] Elephants { get; protected set; }

        List<Piece> mPieces = new List<Piece>(ru.NumPieces);
        internal List<Piece> Pieces { get { return mPieces; } }

        public int RabbitsOnBoard
        {
            get
            {
                int num = 0;
                foreach (PieceRabbit rabbit in this.Rabbits)
                    if (rabbit.Square != null)
                        ++num;
                return num;
            }
        }

        public bool RabbitsAtFinishLine
        {
            get
            {
                int finishLine = this.Color == ae.PlayerColor.Gold ? Board.WinRankIndexGold : Board.WinRankIndexSilver;
                foreach (PieceRabbit rabbit in this.Rabbits)
                    if (rabbit.Square != null && rabbit.Square.Rank == finishLine)
                        return true;
                return false;
            }
        }
        #endregion Properties

        #region Constructors
        public Player(Game game, ae.PlayerColor color, ae.Intelligence intelligence)
        {
            this.Game = game;
            this.Color = color;
            this.Intelligence = intelligence;

            this.Rabbits = CreatePieces<PieceRabbit>(ru.NumRabbits);
            this.Cats = CreatePieces<PieceCat>(ru.NumCats);
            this.Dogs = CreatePieces<PieceDog>(ru.NumDogs);
            this.Horses = CreatePieces<PieceHorse>(ru.NumHorses);
            this.Camels = CreatePieces<PieceCamel>(ru.NumCamels);
            this.Elephants = CreatePieces<PieceElephant>(ru.NumElephants);

            this.Pieces.AddRange(this.Rabbits);
            this.Pieces.AddRange(this.Cats);
            this.Pieces.AddRange(this.Dogs);
            this.Pieces.AddRange(this.Horses);
            this.Pieces.AddRange(this.Camels);
            this.Pieces.AddRange(this.Elephants);
        }
        #endregion Constructors

        #region Piece[] accessors
        public Piece[] GetPieces(ae.PieceType pieceType)
        {
            switch (pieceType)
            {
                case ae.PieceType.Elephant:
                    return this.Elephants;
                case ae.PieceType.Camel:
                    return this.Camels;
                case ae.PieceType.Horse:
                    return this.Horses;
                case ae.PieceType.Dog:
                    return this.Dogs;
                case ae.PieceType.Cat:
                    return this.Cats;
                case ae.PieceType.Rabbit:
                    return this.Rabbits;
                default:
                    return null;
            }
        }

        public Piece[] GetPieces(char abbreviation)
        {
            switch (abbreviation)
            {
                case PieceElephant.AbbreviationGold:
                case PieceElephant.AbbreviationSilver:
                    return this.Elephants;
                case PieceCamel.AbbreviationGold:
                case PieceCamel.AbbreviationSilver:
                    return this.Camels;
                case PieceHorse.AbbreviationGold:
                case PieceHorse.AbbreviationSilver:
                    return this.Horses;
                case PieceDog.AbbreviationGold:
                case PieceDog.AbbreviationSilver:
                    return this.Dogs;
                case PieceCat.AbbreviationGold:
                case PieceCat.AbbreviationSilver:
                    return this.Cats;
                case PieceRabbit.AbbreviationGold:
                case PieceRabbit.AbbreviationSilver:
                    return this.Rabbits;
                default:
                    return null;
            }
        }
        #endregion Piece[] accessors

        #region Shadow
        public void CreateShadow()
        {
            CreateShadows<PieceRabbit>(this.Rabbits);
            CreateShadows<PieceCat>(this.Cats);
            CreateShadows<PieceDog>(this.Dogs);
            CreateShadows<PieceHorse>(this.Horses);
            CreateShadows<PieceCamel>(this.Camels);
            CreateShadows<PieceElephant>(this.Elephants);
        }

        protected void CreateShadows<T>(T[] pieces) where T : Piece, new()
        {
            foreach (T piece in pieces)
            {
                piece.Shadow = new T();
                piece.Shadow.ShadowOf = piece;
                piece.Shadow.Player = this;
            }
        }

        public void SyncShadow()
        {
            foreach (Piece piece in this.Pieces)
            {
                piece.Shadow.Square = piece.Square == null ? null : piece.Square.Shadow;
            }
        }
        #endregion Shadow

        #region Helper Functions
        protected T[] CreatePieces<T>(int count) where T : Piece, new()
        {
            T[] pArray = new T[count];
            for (int i = 0; i < count; ++i)
            {
                pArray[i] = new T();
                pArray[i].Player = this;
            }
            return pArray;
        }
        #endregion Helper Functions

        #region Static Helper Functions
        public static ae.PlayerColor GetPlayerColor(char playerChar)
        {
            switch (playerChar)
            {
                case Player.GoldChar:
                case Player.GoldCharAlt:
                    return ae.PlayerColor.Gold;
                case Player.SilverChar:
                case Player.SilverCharAlt:
                    return ae.PlayerColor.Silver;
                default:
                    throw new ArgumentException("playerChar");
            }
        }
        #endregion Static Helper Functions

    }
}
