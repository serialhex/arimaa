﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace ZeroGravitas
{
    public class Turn : List<Move>
    {
        public int TurnNumber { get; protected set; }
        public ae.PlayerColor PlayerColor { get; protected set; }

        public Turn()
            : base()
        {
            this.TurnNumber = 0;
            this.PlayerColor = ae.PlayerColor.Gold;
        }

        public Turn(int turn, ae.PlayerColor player)
            : base()
        {
            this.TurnNumber = turn;
            this.PlayerColor = player;
        }

        public Turn(int turn, ae.PlayerColor player, int capacity)
            : base(capacity)
        {
            this.TurnNumber = turn;
            this.PlayerColor = player;
        }

        public Turn(Turn other)
            : base(other)
        {
            this.TurnNumber = other.TurnNumber;
            this.PlayerColor = other.PlayerColor;
        }

        public Turn(int turn, ae.PlayerColor player, IEnumerable<Move> collection)
            : base(collection)
        {
            this.TurnNumber = turn;
            this.PlayerColor = player;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(128);
            if (this.Count != 0)
                this[0].AppendNotation(sb);
            for (int i = 1; i < this.Count; ++i)
            {
                sb.Append(' ');
                this[i].AppendNotation(sb);
            }
            return sb.ToString();
        }

        public List<Move> GetUndoMoves()
        {
            List<Move> unmoves = new List<Move>(this.Count);
            for (int i = this.Count - 1; i >= 0; --i)
                this[i].AddUndoMoves(unmoves);
            return unmoves;
        }

        public static Turn GetTurn(string notationLine)
        {
            Match mTurn = ae.rexTurn.Match(notationLine);
            if (!mTurn.Success)
                return null;

            char cPlayerColor = mTurn.Groups["pl"].Value[0];
            ae.PlayerColor playerColor = Player.GetPlayerColor(cPlayerColor);

            int turnNumber = int.Parse(mTurn.Groups["t"].Value);

            string sCurTurnMoves = mTurn.Groups["m"].Value;

            return new Turn(turnNumber, playerColor, Move.GetMoves(playerColor, sCurTurnMoves));
        }

        public static List<Turn> GetTurns(string[] notationLines)
        {
            List<Turn> turns = new List<Turn>(ru.AverageTurnsPerGame);

            foreach (string notationLine in notationLines)
            {
                Turn t = Turn.GetTurn(notationLine);
                if (t != null && t.Count != 0)
                    turns.Add(t);
            }

            return turns;
        }

        /// <summary>
        /// Returns a new list with all takeback moves and taken back turns removed.
        /// </summary>
        /// <param name="sparseTurns">A list of turns containing takeback moves and taken-back turns.</param>
        /// <returns>A compressed list of turns, missing all takeback moves and the turns taken back by those takeback moves.</returns>
        public static List<Turn> GetCompressedTurns(IList<Turn> sparseTurns)
        {
            List<Turn> turns = new List<Turn>(ru.AverageTurnsPerGame);

            for (int i = 0; i < sparseTurns.Count; ++i)
            {
                Turn t = sparseTurns[i];
                if (t.Count == 0)
                    continue;
                if (t[0].Action == ae.Action.Takeback)
                {
                    if (turns.Count != 0)
                        turns.RemoveAt(turns.Count - 1);
                }
                else
                    turns.Add(t);
            }

            return turns;
        }

        public static List<Turn> GetCompressedTurns(string[] notationLines)
        {
            return Turn.GetCompressedTurns(Turn.GetTurns(notationLines));
        }
    }
}
