﻿using System;
using System.Text.RegularExpressions;

namespace ZeroGravitas
{
    public class ae
    {
        public enum GameState
        {
            Null,
            Initialization,
            GoldSetup,
            SilverSetup,
            GoldsTurn,
            SilversTurn,
            GoldWins,
            SilverWins
        }

        public enum GameStateType
        {
            Null,
            Initialization,
            Setup,
            Play,
            End
        }

        public enum PlayerColor
        {
            Gold = 0,
            Silver
        }

        public enum SquareColor
        {
            White = 0,
            Black
        }

        public enum Intelligence
        {
            Human,
            Computer
        }

        public enum PieceType
        {
            Null,
            Rabbit,
            Cat,
            Dog,
            Horse,
            Camel,
            Elephant
        }

        [Flags]
        public enum Movement
        {
            Null = 0,
            Forward = 1,
            Right = 2,
            Backward = 4,
            Left = 8,
            All = Forward | Right | Backward | Left
        }

        public enum Direction
        {
            Null = -1,
            North,
            East,
            South,
            West
        }

        [Flags]
        public enum DirFlag
        {
            Null = 0,
            North = 1,
            East = 2,
            South = 4,
            West = 8
        }

        public enum Action
        {
            Null,
            Place,
            Move,
            PullOther,
            PushOther,
            PulledByOther,
            PushedByOther,
            Remove,
            Takeback
        }

        public enum InvalidMove
        {
            Null,
            GameStateInvalid,
            MoveObjectInvalid,
            OutOfTurn,
            CannotMoveEnemyPiece,
            InvalidStartPosition,
            PieceNotFound,
            OriginSquareNotFound,
            DestinationSquareNotFound,
            OriginSquareIncorrect,
            SquaresNotAdjacent,
            DestinationSquareOccupied,
            InsufficientMovesRemaining,
            MustFollowThroughOnPush,
            PieceFrozen,
            PieceTypeMovementRestricted,
            CannotPushEnemyPieceWithThisPiece,
            NoAdjacentPiecesCanPushThisPiece,
            AllAdjacentPiecesForPushingAreFrozen,
            CannotRepeatPreviousBoardPosition,
            MustChangeBoardPosition
        }

        #region Regex
        /// <summary>
        /// Position notation, consisting of file and rank.
        /// <example>a1 b2 c3 d4 h8</example>
        /// </summary>
        public static readonly Regex rexPosNotation = new Regex(@"\b(?<f>\w)(?<r>\d+)\b", RegexOptions.Compiled | RegexOptions.ExplicitCapture);

        /// <summary>
        /// Initialization notation, consisting of piece type (caps for gold), file, and rank.
        /// <example>Da1 Ca2 Eb1 Mb2</example>
        /// </summary>
        public static readonly Regex rexInitNotation = new Regex(@"\b(?<p>\w)(?<f>\w)(?<r>\d+)\b", RegexOptions.Compiled | RegexOptions.ExplicitCapture);

        /// <summary>
        /// Movement notation, consisting of piece type (caps for gold), file, rank, and (optionally) direction of movement.
        /// <example>Dd1n Mb3e Mc3e hc4s hc3x</example>
        /// </summary>
        public static readonly Regex rexMovNotation = new Regex(@"\b(?<p>\w)(?<f>\w)(?<r>\d+)(?<d>[" + lng.North + lng.East + lng.South + lng.West + lng.Removal + @"]?)\b", RegexOptions.Compiled | RegexOptions.ExplicitCapture);

        /// <summary>
        /// Takeback notation, consisting of nothing more than the whole word "takeback" (as defined in the language class).
        /// </summary>
        public static readonly Regex rexTakeback = new Regex(@"\b" + lng.TakebackMove + @"\b", RegexOptions.Compiled | RegexOptions.ExplicitCapture | RegexOptions.Multiline | RegexOptions.IgnoreCase);

        /// <summary>
        /// Position file notation, consisting of turn number and player color indicator, and (optionally) the moves already taken this turn.
        /// <example>7g Dd1n Mb3e Mc3e</example>
        /// </summary>
        public static readonly Regex rexTurn = new Regex(@"\b(?<t>\d+)(?<pl>[" + Player.LegalColorChars + @"])\s*(?<m>.*)", RegexOptions.Compiled | RegexOptions.ExplicitCapture | RegexOptions.Multiline);

        /// <summary>
        /// Board position notation, signifying a single rank of a board position file.
        /// </summary>
        public static readonly Regex rexPosFileLine = new Regex(@"\s*(?<r>\d+)?(\s*\|)?(\s(?<s>[\w\s\.])){" + Board.NumFiles + @"}(\s*\|)?", RegexOptions.Compiled | RegexOptions.ExplicitCapture | RegexOptions.Multiline);
        #endregion Regex
    }
}
