﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace ZeroGravitas
{
    public interface IMove
    {
        ae.PlayerColor PlayerColor { get; }
        ae.PlayerColor PieceColor { get; }
        ae.PieceType PieceType { get; }
        int File { get; }
        int Rank { get; }
        ae.Direction Direction { get; }

        char FileName { get; }
        string RankName { get; }
        ae.Action Action { get; }
        bool Coerced { get; }
        IEnumerable<IMove> GetIncidentalMoves();

        string Notation { get; }
        StringBuilder AppendNotation(StringBuilder sb);
    }
}
