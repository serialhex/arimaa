﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZeroGravitas
{
    public interface IPiece
    {
        #region Play
        Piece Base { get; }

        ae.PlayerColor Color { get; }

        Player Player { get; }

        Square StartingSquare { get; } // TODO: Track StartingSquare.

        Square Square { get; }

        bool HasMoved { get; } // TODO: Track HasMoved.

        bool IsInPlay { get; } // TODO: Track IsInPlay.

        int NumMoves { get; } // TODO: Track NumMoves.

        int LastMoveOn { get; } // TODO: Track LastMoveOn.

        int Value { get; }

        bool CanPush(Piece other);

        bool CanPull(Piece other);

        bool CanFreeze(Piece other);

        bool IsFrozen { get; }

        bool CanBePulled { get; }

        bool CanBePushed { get; }

        ae.Movement Movement { get; }

        ae.DirFlag Vacancies { get; }
        ae.DirFlag Allies { get; }
        ae.DirFlag Freezers { get; }
        ae.DirFlag Pullers { get; }
        ae.DirFlag Pushers { get; }
        #endregion Play

        #region Display
        char Abbreviation { get; }

        ae.PieceType PieceType { get; }

        int ImageIndex { get; }
        #endregion Display
    }
}
