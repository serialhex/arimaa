﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZeroGravitas
{
    public class lng
    {
        public const char Removal = 'x';

        public const char North = 'n';
        public const char East = 'e';
        public const char South = 's';
        public const char West = 'w';

        public const char WhiteSquare = ' ';
        public const char BlackSquare = '.';

        public const char AbvGoldElephant = 'E';
        public const char AbvGoldCamel = 'M';
        public const char AbvGoldHorse = 'H';
        public const char AbvGoldDog = 'D';
        public const char AbvGoldCat = 'C';
        public const char AbvGoldRabbit = 'R';

        public const char AbvSilverElephant = 'e';
        public const char AbvSilverCamel = 'm';
        public const char AbvSilverHorse = 'h';
        public const char AbvSilverDog = 'd';
        public const char AbvSilverCat = 'c';
        public const char AbvSilverRabbit = 'r';

        public const char UnknownPieceType = '!';
        public const char UnknownDirection = '?';

        public const string TakebackMove = "takeback";
    }
}
