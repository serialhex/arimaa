﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace ZeroGravitas
{
    public class Move : IMove
    {
        #region Properties
        public ae.PlayerColor PlayerColor { get; protected set; }
        public ae.PlayerColor PieceColor { get; protected set; }
        public ae.PieceType PieceType { get; protected set; }
        public int File { get; protected set; }
        public int Rank { get; protected set; }
        public ae.Direction Direction { get; protected set; }

        public char FileName { get { return Board.FileNames[File]; } }
        public string RankName { get { return (Rank + 1).ToString(); } }
        public ae.Action Action { get; protected set; }
        public bool Coerced { get { return this.PlayerColor != this.PieceColor; } }
        public List<Move> IncidentalMoves { get; protected set; }
        public IEnumerable<IMove> GetIncidentalMoves() { return (IEnumerable<IMove>)this.IncidentalMoves; }

        public string Notation { get { return this.AppendNotation(new StringBuilder(128)).ToString(); } }
        #endregion Properties

        #region Constructors
        public Move()
        { }

        public Move(MoveRecord move)
        {
            this.PlayerColor = move.Player.Color;
            this.PieceColor = move.Piece.Player.Color;
            this.PieceType = move.Piece.PieceType;
            this.File = move.From.File;
            this.Rank = move.From.Rank;
            this.Direction = move.From.GetDirectionToAdjacent(move.To);
            this.Action = move.Action;
        }

        public Move(ae.PlayerColor player, ae.PlayerColor pieceColor, ae.PieceType pieceType, int fileIndex, int rankIndex, ae.Action action)
        {
            this.PlayerColor = player;
            this.PieceColor = pieceColor;
            this.PieceType = pieceType;
            this.File = fileIndex;
            this.Rank = rankIndex;
            this.Direction = ae.Direction.Null;
            this.Action = action;
        }


        public Move(ae.PlayerColor player, ae.PlayerColor pieceColor, ae.PieceType pieceType, int fileIndex, int rankIndex, ae.Direction direction)
        {
            this.PlayerColor = player;
            this.PieceColor = pieceColor;
            this.PieceType = pieceType;
            this.File = fileIndex;
            this.Rank = rankIndex;
            this.Direction = direction;
            this.Action = ae.Action.Move;
        }

        public Move(char playerColor, char pieceType, char file, int rankNumber)
        {
            this.PlayerColor = Player.GetPlayerColor(playerColor);
            {
                ae.PlayerColor pc;
                ae.PieceType pt;
                Piece.GetInfo(pieceType, out pc, out pt);
                this.PieceColor = pc;
                this.PieceType = pt;
            }
            this.File = Board.GetFileIndex(file);
            this.Rank = rankNumber - 1;
            this.Direction = ae.Direction.Null;
            this.Action = ae.Action.Place;
        }

        public Move(char playerColor, char pieceType, char file, int rankNumber, char direction)
        {
            this.PlayerColor = Player.GetPlayerColor(playerColor);
            {
                ae.PlayerColor pc;
                ae.PieceType pt;
                Piece.GetInfo(pieceType, out pc, out pt);
                this.PieceColor = pc;
                this.PieceType = pt;
            }
            this.File = Board.GetFileIndex(file);
            this.Rank = rankNumber - 1;
            this.Direction = Board.GetDirection(direction);
            this.Action = this.Direction == ae.Direction.Null ? ae.Action.Remove : ae.Action.Move;
        }

        public Move(ae.PlayerColor player, string notation)
        {
            Match m = ae.rexMovNotation.Match(notation);
            if (!m.Success)
                throw new ArgumentException("Must be in Arimaa placement/move/remove notation.", "notation");

            char pieceType = m.Groups["p"].Value[0];
            char file = m.Groups["f"].Value[0];
            int rankNumber = int.Parse(m.Groups["r"].Value);
            string sDirection = m.Groups["d"].Value;

            this.PlayerColor = player;
            {
                ae.PlayerColor pc;
                ae.PieceType pt;
                Piece.GetInfo(pieceType, out pc, out pt);
                this.PieceColor = pc;
                this.PieceType = pt;
            }
            this.File = Board.GetFileIndex(file);
            this.Rank = rankNumber - 1;
            this.Direction = ae.Direction.Null;

            if (string.IsNullOrEmpty(sDirection))
            {   // Initial placement.
                this.Action = ae.Action.Place;
            }
            else
            {
                char cDirection = sDirection[0];
                if (cDirection == lng.Removal)
                {   // Removal.
                    this.Action = ae.Action.Remove;
                }
                else
                {   // Movement.
                    this.Action = ae.Action.Move;
                    this.Direction = Board.GetDirection(cDirection);
                }
            }
        }

        public Move(char playerColor, string notation)
            : this(Player.GetPlayerColor(playerColor), notation)
        { }
        #endregion Constructors

        #region AddIncidentalMoves
        internal void AddIncidentalMoves(IList<MoveRecord> inmoves)
        {
            if (inmoves == null)
                return;
            if (this.IncidentalMoves == null)
                this.IncidentalMoves = new List<Move>(inmoves.Count);
            foreach (MoveRecord inmove in inmoves)
                this.IncidentalMoves.Add(new Move(inmove));
        }
        #endregion AddIncidentalMoves

        #region GetUndoMoves
        public List<Move> GetUndoMoves()
        {
            List<Move> unmoves = new List<Move>(ru.AverageIncidentalMoves);
            this.AddUndoMoves(unmoves);
            return unmoves;
        }

        internal void AddUndoMoves(IList<Move> unmoves)
        {
            if (this.IncidentalMoves != null)
                for (int i = this.IncidentalMoves.Count - 1; i >= 0; --i)
                    this.IncidentalMoves[i].AddUndoMoves(unmoves);

            Move unmove = null;
            switch (this.Action)
            {
                case ae.Action.Place:
                    unmove = new Move(this.PlayerColor, this.PieceColor, this.PieceType, this.File, this.Rank, ae.Action.Remove);
                    break;
                case ae.Action.Remove:
                    unmove = new Move(this.PlayerColor, this.PieceColor, this.PieceType, this.File, this.Rank, ae.Action.Place);
                    break;
                default:
                    int h = 0, v = 0;
                    ae.Direction back = ae.Direction.Null;

                    switch (this.Direction)
                    {
                        case ae.Direction.North:
                            v = 1;
                            back = ae.Direction.South;
                            break;
                        case ae.Direction.East:
                            h = 1;
                            back = ae.Direction.West;
                            break;
                        case ae.Direction.South:
                            v = -1;
                            back = ae.Direction.North;
                            break;
                        case ae.Direction.West:
                            h = -1;
                            back = ae.Direction.East;
                            break;
                        default:
                            break;
                    }
                    unmove = new Move(this.PlayerColor, this.PieceColor, this.PieceType, this.File + h, this.Rank + v, back);
                    break;
            }
            unmoves.Add(unmove);
        }
        #endregion GetUndoMoves

        #region ToString
        public override string ToString()
        {
            return this.Notation;
        }

        public StringBuilder AppendNotation(StringBuilder sb)
        {
            switch (this.Action)
            {
                case ae.Action.Place:
                    sb.AppendFormat("{0}{1}{2}", Piece.GetPieceChar(this.PieceColor, this.PieceType), this.FileName, this.RankName);
                    break;
                case ae.Action.Remove:
                    sb.AppendFormat("{0}{1}{2}" + lng.Removal, Piece.GetPieceChar(this.PieceColor, this.PieceType), this.FileName, this.RankName);
                    break;
                case ae.Action.Move:
                    sb.AppendFormat("{0}{1}{2}{3}", Piece.GetPieceChar(this.PieceColor, this.PieceType), this.FileName, this.RankName, Board.GetDirectionChar(this.Direction));
                    break;
                case ae.Action.Takeback:
                    sb.Append(lng.TakebackMove);
                    break;
                default:
                    break;
            }

            if (this.IncidentalMoves != null && this.IncidentalMoves.Count != 0)
                foreach (Move move in this.IncidentalMoves)
                {
                    sb.Append(' ');
                    move.AppendNotation(sb);
                }
            return sb;
        }
        #endregion ToString

        #region operators
        public static bool operator ==(Move a, Move b)
        {
            // If both are null, or both are same instance, return true.
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            // If one is null, but not both, return false.
            if (((object)a == null) || ((object)b == null))
            {
                return false;
            }

            return a.PlayerColor == b.PlayerColor
                && a.PieceColor == b.PieceColor
                && a.PieceType == b.PieceType
                && a.File == b.File
                && a.Rank == b.Rank
                && a.Direction == b.Direction
                && a.Action == b.Action;
        }
        public static bool operator !=(Move a, Move b)
        {
            return !(a == b);
        }

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        #endregion operators

        #region Static Helper Functions
        public static List<Move> GetMoves(ae.PlayerColor playerColor, string notationLine)
        {
            List<Move> moves = new List<Move>(ru.MovesPerTurn);

            Match m = ae.rexMovNotation.Match(notationLine);

            while (m.Success)
            {
                Move move = new Move(playerColor, m.Value);
                moves.Add(move);

                m = m.NextMatch();
            }

            if (moves.Count == 0 && ae.rexTakeback.IsMatch(notationLine))
            {
                Move move = new Move();
                move.Action = ae.Action.Takeback;
                moves.Add(move);
            }

            return moves;
        }

        public static List<Move> GetUndoMoves(ae.PlayerColor playerColor, string notationLine)
        {
            return GetUndoMoves(GetMoves(playerColor, notationLine));
        }

        public static List<Move> GetUndoMoves(IList<Move> moves)
        {
            List<Move> unmoves = new List<Move>(moves.Count * (1 + ru.AverageIncidentalMoves));

            for (int i = moves.Count - 1; i >= 0; --i)
                moves[i].AddUndoMoves(unmoves);

            return unmoves;
        }
        #endregion Static Helper Functions
    }
}
