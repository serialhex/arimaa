﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace ZeroGravitas
{
    public class MoveRecord : IMove
    {
        #region Properties
        public Player Player { get; protected internal set; }
        public Piece Piece { get; protected set; }
        public Square From { get; protected set; }
        public Square To { get; protected set; }

        public ae.PlayerColor PlayerColor { get { return this.Player.Color; } }
        public ae.PlayerColor PieceColor { get { return this.Piece.Color; } }
        public ae.PieceType PieceType { get { return this.Piece.PieceType; } }
        public int File { get { return (this.From ?? this.To).File; } }
        public int Rank { get { return (this.From ?? this.To).Rank; } }
        public ae.Direction Direction { get { return this.From == null ? ae.Direction.Null : this.From.GetDirectionToAdjacent(this.To); } }
        public char FileName { get { return (this.From ?? this.To).FileName; } }
        public string RankName { get { return (this.From ?? this.To).RankName; } }

        public int Tick { get; protected set; }
        public int Turn { get; protected set; }
        public int TurnMoveIndex { get; protected set; }

        public bool Placed { get { return this.From == null; } }
        public bool Removed { get { return this.To == null; } }
        public bool Moved { get { return this.From != null && this.To != null; } }
        public bool Valid { get { return this.Piece != null && (this.From != null || this.To != null); } }

        public bool Coerced { get { return this.Piece.Player.Color != this.Player.Color; } }
        public ae.Action Action { get; internal protected set; }

        public List<MoveRecord> IncidentalMoves { get; protected set; }
        public IEnumerable<IMove> GetIncidentalMoves() { return (IEnumerable<IMove>)this.IncidentalMoves; }

        public string Notation { get { return this.AppendNotation(new StringBuilder(128)).ToString(); } }
        #endregion Properties

        #region Constructors
        public MoveRecord(Game game, Move move)
        {
            this.Player = game.GetPlayer(move.PlayerColor);
            this.From = game.Board.GetSquare(move.File, move.Rank);
            this.To = this.From == null ? null : this.From.GetSquare(move.Direction);
            this.Piece = this.From == null ? null : this.From.Piece;

            if (move.Action == ae.Action.Takeback)
                this.Action = ae.Action.Takeback;
            else if (this.Piece == null)
            {
                if (move.Action == ae.Action.Place)
                {
                    this.Piece = game.GetFreePieceForSetup(move.PlayerColor, move.PieceType);
                    this.To = this.From;
                    this.From = null;
                }
            }
            else if (this.Piece != null && this.Piece.PieceType != move.PieceType)
                this.Piece = null;

            AddIncidentalMoves(move.IncidentalMoves);
        }

        public MoveRecord(Game game, Move move, ae.Action action, int tick, int turn, int turnmoveindex)
            : this(game, move)
        {
            this.Action = action;
            this.Tick = tick;
            this.Turn = turn;
            this.TurnMoveIndex = turnmoveindex;
        }

        public MoveRecord(Player player, Piece piece, Square from, Square to)
        {
            this.Action = ae.Action.Null;
            this.Player = player;
            this.Piece = piece;
            this.From = from;
            this.To = to;
        }

        public void Apply(ae.Action action, int tick, int turn, int turnmoveindex)
        {
            this.Action = action;
            this.Tick = tick;
            this.Turn = turn;
            this.TurnMoveIndex = turnmoveindex;
        }
        #endregion Constructors

        #region AddIncidentalMoves
        internal void AddIncidentalMove(MoveRecord other)
        {
            if (this.IncidentalMoves == null)
                this.IncidentalMoves = new List<MoveRecord>(ru.AverageIncidentalMoves);
            this.IncidentalMoves.Add(other);
        }

        internal void AddIncidentalMoves(IList<Move> inmoves)
        {
            if (inmoves == null)
                return;
            if (this.IncidentalMoves == null)
                this.IncidentalMoves = new List<MoveRecord>(inmoves.Count);
            foreach (Move inmove in inmoves)
                this.IncidentalMoves.Add(new MoveRecord(this.Player.Game, inmove));
        }
        #endregion AddIncidentalMoves

        #region GetUndoMoves
        public List<MoveRecord> GetUndoMoves()
        {
            List<MoveRecord> unmoves = new List<MoveRecord>(ru.AverageIncidentalMoves);
            this.AddUndoMoves(unmoves);
            return unmoves;
        }

        internal void AddUndoMoves(IList<MoveRecord> unmoves)
        {
            if (this.IncidentalMoves != null)
                for (int i = this.IncidentalMoves.Count - 1; i >= 0; --i)
                    this.IncidentalMoves[i].AddUndoMoves(unmoves);

            MoveRecord unmove = new MoveRecord(this.Player, this.Piece, this.To, this.From);
            unmoves.Add(unmove);
        }
        #endregion GetUndoMoves

        #region ToString
        public override string ToString()
        {
            return this.Notation;
        }

        public StringBuilder AppendNotation(StringBuilder sb)
        {
            char abv = this.Piece == null ? lng.UnknownPieceType : this.Piece.Abbreviation;

            if (this.Placed)
                sb.AppendFormat("{0}{1}", abv, this.To.Name);
            else if (this.Removed)
                sb.AppendFormat("{0}{1}" + lng.Removal, abv, this.From.Name);
            else if (this.Moved)
                sb.AppendFormat("{0}{1}{2}", abv, this.From.Name, Board.GetDirectionChar(this.From.GetDirectionToAdjacent(this.To)));
            else if (this.Action == ae.Action.Takeback)
                sb.Append(lng.TakebackMove);
            else
                throw new NullReferenceException("The source and destination square are both null. That doesn't make sense!"); // throw, for now.

            if (this.IncidentalMoves != null && this.IncidentalMoves.Count != 0)
                foreach (MoveRecord move in this.IncidentalMoves)
                {
                    sb.Append(' ');
                    move.AppendNotation(sb);
                }
            return sb;
        }
        #endregion ToString
    }
}
