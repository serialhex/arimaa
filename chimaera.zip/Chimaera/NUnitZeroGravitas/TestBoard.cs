﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using ZeroGravitas;

namespace NUnitZeroGravitas
{
    [TestFixture]
    public class TestBoard
    {
        [Test]
        public void T00_BoardTraps()
        {
            Game g = new Game();
            Square sq = null;

            sq = g.Board.GetSquare("c3");
            Assert.NotNull(sq, "square c3");
            Assert.AreEqual("c3", sq.Name);
            Assert.IsTrue(sq.IsTrap, "square c3 trap");

            sq = g.Board.GetSquare("c6");
            Assert.NotNull(sq, "square c6");
            Assert.AreEqual("c6", sq.Name);
            Assert.IsTrue(sq.IsTrap, "square c6 trap");

            sq = g.Board.GetSquare("f3");
            Assert.NotNull(sq, "square f3");
            Assert.AreEqual("f3", sq.Name);
            Assert.IsTrue(sq.IsTrap, "square f3 trap");

            sq = g.Board.GetSquare("f6");
            Assert.NotNull(sq, "square f6");
            Assert.AreEqual("f6", sq.Name);
            Assert.IsTrue(sq.IsTrap, "square f6 trap");
        }

        [Test]
        public void T01_Board_WhiteOnRight()
        {
            Game g = new Game();
            Square sq = null;

            sq = g.Board.GetSquare(0, 0);
            Assert.NotNull(sq, "square a1");
            Assert.AreEqual("a1", sq.Name);
            Assert.IsTrue(sq.Color == ae.SquareColor.Black, "a1 black");

            sq = g.Board.GetSquare(Board.MaxFile, Board.NumRanks);
            Assert.NotNull(sq, "square h8");
            Assert.AreEqual("h8", sq.Name);
            Assert.IsTrue(sq.Color == ae.SquareColor.Black, "h8 black");

            sq = g.Board.GetSquare(0, Board.NumRanks - 1);
            Assert.NotNull(sq, "square a8");
            Assert.AreEqual("a8", sq.Name);
            Assert.IsTrue(sq.Color == ae.SquareColor.White, "a8 white");

            sq = g.Board.GetSquare(Board.MaxFile, 1);
            Assert.NotNull(sq, "square h1");
            Assert.AreEqual("h1", sq.Name);
            Assert.IsTrue(sq.Color == ae.SquareColor.White, "h1 white");
        }

        [Test]
        public void T02_Board_Coordinates()
        {
            Game g = new Game();
            Square sq_ii = null, sq_ai = null, sq_ns = null;

            sq_ii = g.Board.GetSquare(2, 5);
            sq_ai = g.Board.GetSquare('c', 6);
            sq_ns = g.Board.GetSquare("c6");

            Assert.AreSame(sq_ii, sq_ai, "i,i and a,i");
            Assert.AreSame(sq_ii, sq_ns, "i,i and notation string");
        }
    }
}
