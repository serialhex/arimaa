﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using NUnit.Framework;
using ZeroGravitas;

namespace NUnitZeroGravitas
{
    [TestFixture]
    public class TestGame
    {
        public const string gameFileHeaderLine = "id	wplayerid	bplayerid	wusername	busername	wtitle	btitle	wcountry	bcountry	wrating	brating	wratingk	bratingk	wtype	btype	event	site	timecontrol	postal	startts	endts	result	termination	plycount	mode	rated	movelist	events";

        public Game initCommonGame()
        {
            Game g = new Game();
            g.InitializeFromBoardLayout(new string[]
                {
                "2g",
                " +-----------------+",
                "8| d c r h r r c d |",
                "7| r r m h r r r e |",
                "6|     x     x     |",
                "5|                 |",
                "4|                 |",
                "3|     x     x     |",
                "2| D C D H R H E M |",
                "1| C R R R R R R R |",
                " +-----------------+",
                "   a b c d e f g h  ",
                }
            );
            return g;
        }

        [Test]
        public void T00_Game_CountPieces()
        {
            Game g = new Game();

            Assert.AreEqual(8, g.Gold.Rabbits.Length, "Gold Rabbits");
            Assert.AreEqual(2, g.Gold.Cats.Length, "Gold Cats");
            Assert.AreEqual(2, g.Gold.Dogs.Length, "Gold Dogs");
            Assert.AreEqual(2, g.Gold.Horses.Length, "Gold Horses");
            Assert.AreEqual(1, g.Gold.Camels.Length, "Gold Camels");
            Assert.AreEqual(1, g.Gold.Elephants.Length, "Gold Elephants");

            Assert.AreEqual(8, g.Silver.Rabbits.Length, "Silver Rabbits");
            Assert.AreEqual(2, g.Silver.Cats.Length, "Silver Cats");
            Assert.AreEqual(2, g.Silver.Dogs.Length, "Silver Dogs");
            Assert.AreEqual(2, g.Silver.Horses.Length, "Silver Horses");
            Assert.AreEqual(1, g.Silver.Camels.Length, "Silver Camels");
            Assert.AreEqual(1, g.Silver.Elephants.Length, "Silver Elephants");
        }

        [Test]
        public void T01_Game_PlacePieces()
        {
            Game g = new Game();
            Piece p = null;

            g.Advance();
            Assert.AreEqual(ae.GameState.GoldSetup, g.State);

            p = g.Gold.Elephants[0];

            g.MakeMove(g.Gold, p, null, g.Board.GetSquare("a1"));
            Assert.AreSame(p, p.Square.Piece, "Piece == Piece.Square.Piece");
            Assert.AreSame(g.Board.GetSquare("a1"), p.Square, "a1 == Piece.Square");

            g.MakeMove(g.Gold, p, g.Board.GetSquare("a1"), g.Board.GetSquare("a2"));
            Assert.AreSame(p, p.Square.Piece, "Piece == Piece.Square.Piece");
            Assert.AreSame(g.Board.GetSquare("a2"), p.Square, "a2 == Piece.Square");
            Assert.IsNull(g.Board.GetSquare("a1").Piece, "a1.Piece");
        }

        [Test]
        public void T02_Game_InitializeFromBoardLayout()
        {
            Game g = new Game();

            string[] posfile = new string[]
            {
                "7g Dc7w Cc2e",
                " +-----------------+",
                "8|   r   r r   r   |",
                "7| m D     h   D c |",
                "6|   r x r r x r   |",
                "5| h   d     c   d |",
                "4| E   H R       M |",
                "3|   R x   R H R   |",
                "2|       C e C     |",
                "1|   R     R   R   |",
                " +-----------------+",
                "   a b c d e f g h  ",
            };

            g.InitializeFromBoardLayout(posfile);

            Console.WriteLine("posfile:");
            Console.WriteLine(string.Join("\n", posfile));
            Console.WriteLine();

            Console.WriteLine("game:");
            Console.WriteLine(g.Representation);

            //g.StartGame();
            //g.Advance();
            Console.WriteLine("legal moves:");
            int t1 = Environment.TickCount;
            Console.WriteLine(g.GetLegalMoveString());
            int t2 = Environment.TickCount;
            int timeTaken = t2 - t1;
            Console.WriteLine("time taken: {0} ms", timeTaken);
        }

        [Test]
        public void T03_Game_Initialize_Start()
        {
            Game g = initCommonGame();
            Console.WriteLine(g.Representation);
            g.StartGame();
            Console.WriteLine(g.GetLegalMoveString());
        }

        [Test]
        public void T04_Game_MoveRabbitBackwards()
        {
            Game g = initCommonGame();
            Console.WriteLine(g.Representation);
            g.StartGame();
            g.MakeMove(ae.PlayerColor.Gold, "Re2n");
            Console.WriteLine(g.Representation);

            Assert.That(delegate() { g.MakeMove(ae.PlayerColor.Gold, "Re3s"); },
                Throws.TypeOf<InvalidMoveException>()
                .With.Property("InvalidMoveReason")
                .EqualTo(ae.InvalidMove.PieceTypeMovementRestricted));
        }

        [Test]
        public void T05_Game_PullRabbit()
        {
            Game g = initCommonGame();
            Console.WriteLine(g.Representation);

            g.MakeCheatMove(g.Gold, PieceElephant.AbbreviationGold, "g2", "g6");
            Console.WriteLine(g.Representation);

            g.StartGame();

            g.MakeMove(ae.PlayerColor.Gold, "Eg6s");
            g.MakeMove(ae.PlayerColor.Gold, "rg7s");

            Console.WriteLine(g.Representation);
        }

        [Test]
        public void T06_Game_PushRabbit_X()
        {
            Game g = initCommonGame();
            Console.WriteLine(g.Representation);

            g.MakeCheatMove(g.Gold, PieceElephant.AbbreviationGold, "g2", "h6");
            Console.WriteLine(g.Representation);
            g.MakeCheatMove(g.Gold, PieceRabbit.AbbreviationSilver, "g7", "g6");
            Console.WriteLine(g.Representation);

            g.StartGame();

            g.MakeMove(ae.PlayerColor.Gold, "rg6w");
            Console.WriteLine(g.Representation);

            g.MakeMove(ae.PlayerColor.Gold, "Eh6w");
            Console.WriteLine(g.Representation);
        }

        [Test]
        public void T07_Game_PushRabbit_X_NoFollowThrough()
        {
            Game g = initCommonGame();
            Console.WriteLine(g.Representation);

            g.MakeCheatMove(g.Gold, PieceElephant.AbbreviationGold, "g2", "h6");
            g.MakeCheatMove(g.Gold, PieceRabbit.AbbreviationSilver, "g7", "g6");
            Console.WriteLine(g.Representation);

            g.StartGame();

            g.MakeMove(ae.PlayerColor.Gold, "rg6w");

            Assert.That(delegate() { g.MakeMove(ae.PlayerColor.Gold, "Eh6s"); },
                Throws.TypeOf<InvalidMoveException>()
                .With.Property("InvalidMoveReason")
                .EqualTo(ae.InvalidMove.MustFollowThroughOnPush));

            Console.WriteLine(g.Representation);
        }

        [Test]
        public void T08_Game_PushRabbit_X_CamelFrozen()
        {
            Game g = initCommonGame();
            Console.WriteLine(g.Representation);

            g.MakeCheatMoveAny(g.Gold, PieceCamel.AbbreviationGold, "h6");
            g.MakeCheatMove(g.Gold, PieceRabbit.AbbreviationSilver, "g7", "g6");
            Console.WriteLine(g.Representation);

            g.StartGame();

            Assert.That(delegate() { g.MakeMove(ae.PlayerColor.Gold, "rg6w"); },
                Throws.TypeOf<InvalidMoveException>()
                .With.Property("InvalidMoveReason")
                .EqualTo(ae.InvalidMove.AllAdjacentPiecesForPushingAreFrozen));

            Console.WriteLine(g.Representation);
        }

        [Test]
        public void T09_Game_PushElephant_X_WithElephant()
        {
            Game g = initCommonGame();
            Console.WriteLine(g.Representation);

            g.MakeCheatMoveAny(g.Gold, PieceElephant.AbbreviationGold, "h6");
            g.MakeCheatMoveAny(g.Gold, PieceElephant.AbbreviationSilver, "g6");
            Console.WriteLine(g.Representation);

            g.StartGame();

            Assert.That(delegate() { g.MakeMove(ae.PlayerColor.Gold, "eg6w"); },
                Throws.TypeOf<InvalidMoveException>()
                .With.Property("InvalidMoveReason")
                .EqualTo(ae.InvalidMove.NoAdjacentPiecesCanPushThisPiece));

            Console.WriteLine(g.Representation);
        }

        [Test]
        public void T10_Game_FreezeCamel()
        {
            Game g = initCommonGame();
            Console.WriteLine(g.Representation);
            g.MakeCheatMove(g.Gold, PieceCamel.AbbreviationGold, "h2", "h6");
            Console.WriteLine(g.Representation);
            g.StartGame();

            Assert.That(delegate() { g.MakeMove(ae.PlayerColor.Gold, "Mh6s"); },
                Throws.TypeOf<InvalidMoveException>()
                .With.Property("InvalidMoveReason")
                .EqualTo(ae.InvalidMove.PieceFrozen));
        }

        [Test]
        public void T11_Game_Repeat_MustChangeBoardPosition()
        {
            Game g = initCommonGame();
            Console.WriteLine(g.Representation);
            g.MakeMove(ae.PlayerColor.Gold, "Eg2n");
            g.MakeMove(ae.PlayerColor.Gold, "Eg3s");
            g.MakeMove(ae.PlayerColor.Gold, "Eg2n");

            Assert.That(delegate() { g.MakeMove(ae.PlayerColor.Gold, "Eg3s"); },
                Throws.TypeOf<InvalidMoveException>()
                .With.Property("InvalidMoveReason")
                .EqualTo(ae.InvalidMove.MustChangeBoardPosition));
        }

        [Test]
        public void T12_Game_Repeat_MustChangeBoardPosition_End_Turn_Early()
        {
            Game g = initCommonGame();
            Console.WriteLine(g.Representation);
            g.MakeMove(ae.PlayerColor.Gold, "Eg2n");
            g.MakeMove(ae.PlayerColor.Gold, "Eg3s");

            Assert.That(delegate() { g.SwitchTurn(g.Silver, false); },
                Throws.TypeOf<InvalidOperationException>());
        }

        [Test]
        public void T13_Game_Repeat_Board_Position()
        {
            Game g = initCommonGame();
            Console.WriteLine(g.Representation);

            g.MakeMove(ae.PlayerColor.Gold, "Eg2n");
            g.SwitchTurn(g.Silver, false);
            Console.WriteLine(g.Representation);
            g.MakeMove(ae.PlayerColor.Silver, "eh7s");
            g.SwitchTurn(g.Gold, true);
            Console.WriteLine(g.Representation);

            g.MakeMove(ae.PlayerColor.Gold, "Eg3s");
            g.SwitchTurn(g.Silver, false);
            Console.WriteLine(g.Representation);
            g.MakeMove(ae.PlayerColor.Silver, "eh6n");
            g.SwitchTurn(g.Gold, true);
            Console.WriteLine(g.Representation);

            g.MakeMove(ae.PlayerColor.Gold, "Eg2n");
            g.SwitchTurn(g.Silver, false);
            Console.WriteLine(g.Representation);
            g.MakeMove(ae.PlayerColor.Silver, "eh7s");
            g.MakeMove(ae.PlayerColor.Silver, "eh6s");
            g.MakeMove(ae.PlayerColor.Silver, "dh8s");
            g.MakeMove(ae.PlayerColor.Silver, "dh7s");
            g.SwitchTurn(g.Gold, true);
            Console.WriteLine(g.Representation);

            g.MakeMove(ae.PlayerColor.Gold, "Eg3s");
            g.SwitchTurn(g.Silver, false);
            Console.WriteLine(g.Representation);

            g.MakeMove(ae.PlayerColor.Silver, "dh6n");
            g.MakeMove(ae.PlayerColor.Silver, "dh7n");
            g.MakeMove(ae.PlayerColor.Silver, "eh5n");

            Console.WriteLine(g.Representation);
            Console.WriteLine("About to repeat the board position a third time with my last move remaining...");

            Assert.That(delegate() { g.MakeMove(ae.PlayerColor.Silver, "eh6n"); },
                Throws.TypeOf<InvalidMoveException>()
                .With.Property("InvalidMoveReason")
                .EqualTo(ae.InvalidMove.CannotRepeatPreviousBoardPosition));
        }

        [Test]
        public void T14_Game_Repeat_Board_Position_End_Turn_Early()
        {
            Game g = initCommonGame();
            Console.WriteLine(g.Representation);

            g.MakeMove(ae.PlayerColor.Gold, "Eg2n");
            g.SwitchTurn(g.Silver, false);
            Console.WriteLine(g.Representation);
            g.MakeMove(ae.PlayerColor.Silver, "eh7s");
            g.SwitchTurn(g.Gold, true);
            Console.WriteLine(g.Representation);

            g.MakeMove(ae.PlayerColor.Gold, "Eg3s");
            g.SwitchTurn(g.Silver, false);
            Console.WriteLine(g.Representation);
            g.MakeMove(ae.PlayerColor.Silver, "eh6n");
            g.SwitchTurn(g.Gold, true);
            Console.WriteLine(g.Representation);

            g.MakeMove(ae.PlayerColor.Gold, "Eg2n");
            g.SwitchTurn(g.Silver, false);
            Console.WriteLine(g.Representation);
            g.MakeMove(ae.PlayerColor.Silver, "eh7s");
            g.SwitchTurn(g.Gold, true);
            Console.WriteLine(g.Representation);

            g.MakeMove(ae.PlayerColor.Gold, "Eg3s");
            g.SwitchTurn(g.Silver, false);
            Console.WriteLine(g.Representation);

            Console.WriteLine("About to repeat the board position a third time and try to end the turn early...");
            Console.WriteLine(g.Representation);

            g.MakeMove(ae.PlayerColor.Silver, "eh6n");
            Console.WriteLine(g.Representation);

            Assert.That(delegate() { g.SwitchTurn(g.Gold, false); },
                Throws.TypeOf<InvalidOperationException>());
        }

        [Test]
        public void T50_Game_LoadGame_FromString()
        {
            using (GameReader gr = new GameReader())
            {
                Game g = null;
                string[] notationLines = null;
                int count = 0;

                gr.Initialize(gameFileHeaderLine);

                string gameFileLine = @"112354	2633	7411	bot_Bomb2005P1	ArifSyed			US	US	1555	2111	30	30	b	h	Casual game	Over the Net	1/1/100/5/0	0	1249109249	1249111259	b	e	66	IGS	1	1w Ra2 Db2 Hc2 Ed2 Me2 Hf2 Dg2 Rh2 Ra1 Rb1 Rc1 Cd1 Ce1 Rf1 Rg1 Rh1\n1b ed7 me7 hg7 df7 ce8 hb7 dc7 cd8 ra7 rh7 ra8 rb8 rc8 rf8 rg8 rh8\n2w Ed2n Ed3n Ed4n Ed5n\n2b hg7s df7e me7e hb7s\n3w Ed6e Ee6n Ee7s mf7w\n3b me7e ed7s ed6s ed5s\n4w Ee6n Db2n Ee7s mf7w\n4b me7e ed4s ed3e rb8s\n5w Ee6n Dg2n Ee7s mf7w\n5b ee3n Me2n me7e rc8w\n6w Ce1n Me3w Md3s\n6b ee4w ed4s ed3e Md2n\n7w Ee6n Cd1n Ee7s mf7w\n7b Md3n ee3w me7e cd8w\n8w Ee6w Ed6s Md4e Ed5s\n8b ed3e Me4n ee3n dc7e\n9w Ed4n Me5n Me6w Ed5e\n9b ee4w ed4n Md6w Mc6x ed5n\n10w Ee5e Ef5e Eg5w hg6s\n10b dg7s hg5e cc8s ed6s\n11w Ef5e Eg5w dg6s Ef5w\n11b dg5n rg8s hh5s hh4s\n12w Ee5e Ef5e Eg5w dg6s\n12b ed5e ee5s ee4e ce8s\n13w Ef5w Ee5n Rh2w\n13b dg5n Dg3n hh3w rb8e\n14w Rg2e Ee6s Ee5s Ee4s\n14b Dg4n hg3n Dg5w hg4n\n15w Ee3n Ee4n Ce2n Ee5n\n15b Df5n hg5w ce7n dd7e\n16w Hf2n Hf3e Ce3e Cf3s\n16b ef4e rf8e mf7n de7e\n17w Rh2w Hg3w Rg2e Hf3w\n17b eg4w ce8s mf8w me8w\n18w He3n Rf1w Re1n Re2n\n18b He4n ef4w md8s md7s\n19w Db3n Db4e Dc4n Dc5e\n19b ce7w hb6s hb5e rh7s\n20w Cd2n Hc2n Hc3w Dd5s\n20b He5w ee4n rh8s rg8w\n21w md6w Ee6w Df6x Dd4e Hd5s\n21b ee5w De4n mc6w rh6s\n22w Ed6e cd7s De5s Ee6s\n22b rh5w hf5n mb6s mb5s\n23w De4e Df4e Dg4s rg5s\n23b dg6s rg4e hf6e rh7s\n24w Ee5s Cd3s Hd4s Ee4w\n24b dg5e hc5n ed5w ec5s\n25w Ed4n Hd3n Ed5w Cd2n\n25b mb4w Hb3n cc7e hc6n\n26w Rc1n Dg3e Dh3w rh4s\n26b hg6s hg5s Dg3s hg4s\n27w Ec5w Hd4e Hb4s Eb5s\n27b ra7s ra6s ma4s ra5s\n28w Hb3s Cd3s Eb4s ra4e\n28b rb4w ec4e ed4s He4w\n29w Cd2e Re3n Ce2n Hd4n\n29b hc7s hc6s cd6e rb7s\n30w Eb3n Hd5e Eb4s ra4e\n30b hc5s rb4w rc8s hc4e\n31w He5e ce6s Hf5e Hg5n\n31b ce5n Re4n hd4e cd7s\n32w Eb3n Eb4s ra4e\n32b Re5w he4n he5s ra8s\n33w Rc2e Hb2e Hg6s rh6w\n33b cd6w Rd5n cc6s Rd6w Rc6x\n34w Hg5w dh5w Hf5w dg5w\n34b he4e Ce3n Ce4w hf4w\n35w Rd2e Re2n Rb1e Ra1e\n35b cc5e Cd4w he4w ra7s\n36w Hc2n Cc4n Hc3s Cc5w\n36b hd4w rb4w hc4n cd5n\n37w Eb3n Cb5w Eb4s ra4e\n37b ed3s Re3w Rd3w ed2n\n38w He5s ce6s He4e ce5s\n38b ed3e ce4w cd4w ee3w\n39w Cf2w Ce2w Dg2w\n39b hc5w hb5e Ca5e ra6s\n40w Hf4w He4n He5w Df2s\n40b df5s hg3s hg2w Rg1n\n41w Rb1w Rh1w Ra2e\n41b hf2w Df1n Df2n Df3x he2e\n42w Rc1e Rd1e Re1e\n42b hf2w Rg2w Rf2n Rf3x he2e\n43w Rf1w Re1w Rd1w\n43b df4e dg4s rf8w re8s\n44w Cd2s Hc2e Rc1n Hd2e\n44b ed3n ed4s Hd5s re7s\n45w Rg1e He2s He1e Hf1e\n45b hc5e Cb5e Cc5n Cc6x hd5w\n46w Hg1n Rc2e Cd1w Cc1n\n46b hf2w he2e Rd2e hc5e\n47w Rb2w Rh1w Ra2e\n47b hf2s Re2e Rf2n Rf3x hf1n\n48w Cc2s Rb2e Rc2e Cc1n\n48b hf2w he2e Rd2e ra5s\n49w Ra1n Cc2w Cb2e\n49b hf2s Re2e Rf2n Rf3x hf1n\n50w Rg1w Hg2s Rf1w Hg1n\n50b hf2w he2e Re1n hd5e\n51w Cc2e Cd2s Cd1e Re2w\n51b he5s he4s he3s rb6w\n52w dg3w Hg2n Hg3s\n52b df3w hf2n hf3e rg6e\n53w Eb3s Rc3x ma3e Eb2e mb3s\n53b cc4s cc3w rg7s df7s\n54w Ec2s mb2e Ec1w Eb1n\n54b ed3w Hd4s ec3n Hd3w Hc3x\n55w cb3w Eb2n Eb3s\n55b ca3e Ra2n Rd2n he2w\n56w mc2s Eb2e Ce1e\n56b Rd3w de3w hd2e he2e\n57w Hg2s Cf1w Hg1n\n57b df6s df5s df4w de4s\n58w Ce1w Hg2s Hg1n\n58b ec4e Rc3n Rc4n ed4w\n59w Ec2e Ed2w dd3s\n59b Rc5n Rc6x ec4n ec5s ra6s\n60w Ec2w Eb2s cb3s\n60b dd2w Cd1n cb2n mc1e\n61w Eb1n Eb2w Ea2e\n61b Cd2n md1n Cd3w Cc3x md2n\n62w Eb2w Hg2s Hg1n\n62b cb3s Ra3e Rb3e Rc3x cb2n\n63w Ea2n Hg2s Hg1n\n63b md3s md2e me2s me1e\n64w Ea3s cb3w Ea2e\n64b mf1e hf2w Hg2w mg1n\n65w dc2n Eb2e dc3w Ec2n Ec3x\n65b Hf2n Hf3x mg2w ec4e ed4s\n66w Rh2w\n66b mf2s Rg2w Rf2n Rf3x he2e\n67w	events";
                if (gr.GetNextGame(gameFileLine, out g, out notationLines))
                {
                    g.Advance();

                    for (int i = 0; i < notationLines.Length; ++i)
                    {
                        string turnNotation = notationLines[i];
                        try
                        {
                            g.PlayEntireTurn(turnNotation);
                            Console.WriteLine(g.Representation);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                            Console.WriteLine("At: game #{0} id:{1}, turn {2}.{3}", count, g.GameId, g.TurnNumber, g.WhoseTurn.Abbreviation);
                            Console.WriteLine(new string(g.Board.ToCharArray()));
                            Console.WriteLine(g.Representation);
                            throw;
                        }
                    }
                    Console.WriteLine("Game #{0} id:{1}, turn {2}.{3}", count, g.GameId, g.TurnNumber, g.WhoseTurn.Abbreviation);
                    Console.WriteLine(g.Representation);
                    ++count;
                }
            }
        }

        [Test]
        public void T51_Game_LoadGame_FromFile()
        {
            using (GameReader gr = new GameReader(@"X:\kayala\games\allgames200908.txt"))
            {
                Game g = null;
                string[] notationLines = null;
                int count = 0;

                while (gr.GetNextGame(out g, out notationLines))
                {
                    g.Advance();

                    for (int i = 0; i < notationLines.Length; ++i)
                    {
                        string turnNotation = notationLines[i];
                        try
                        {
                            string rep = new string(g.Board.ToCharArray());
                            if (rep == "R RDeR.RRMDdCRCRmErchHHRrrr. hrrcr. . r  .xd x .. . . .  . . . .")
                            {
                                Console.WriteLine("spotted at turn {0}{1}!", g.TurnNumber, g.WhoseTurn.Abbreviation);
                                Console.WriteLine(g.Representation);
                            }

                            g.PlayEntireTurn(turnNotation);


                            //if (g.GameId == 112863 && g.TurnNumber > 49)
                            //    Console.WriteLine(g.Representation);
                            //Console.WriteLine(g.Representation);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                            Console.WriteLine("At: game #{0} id:{1}, turn {2}.{3}", count, g.GameId, g.TurnNumber, g.WhoseTurn.Abbreviation);
                            Console.WriteLine(new string(g.Board.ToCharArray()));
                            Console.WriteLine(g.Representation);
                            throw;
                        }
                    }
                    Console.WriteLine("Game #{0} id:{1}, turn {2}.{3}", count, g.GameId, g.TurnNumber, g.WhoseTurn.Abbreviation);
                    Console.WriteLine(g.Representation);
                    ++count;
                }
            }
        }
    }
}
