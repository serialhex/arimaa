﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using NUnit.Framework;
using ZeroGravitas;

namespace NUnitZeroGravitas
{
    [TestFixture]
    public class TestMisc
    {
        [Test]
        public void T00_PosFile_Regex()
        {
            Regex rexPosFileLine = new Regex(@"\s*(\d+\s*\|)?(\s(?<s>[\w\s])){" + Board.NumFiles + @"}(\s*\|)?", RegexOptions.Compiled | RegexOptions.ExplicitCapture | RegexOptions.Multiline);
            string[] x = new string[]
            {
                "7g Da1n Cc1n",
                " +-----------------+",
                "8|   r   r r   r   |",
                "7| m   h     e   c |",
                "6|   r x r r x r   |",
                "5| h   d     c   d |",
                "4| E   H         M |",
                "3|   R x R R H R   |",
                "2| D   C     C   D |",
                "1|   R   R R   R   |",
                " +-----------------+",
                "   a b c d e f g h  ",
            };

            Match m = rexPosFileLine.Match(x[2]);
            Assert.IsTrue(m.Success);

            Group g = m.Groups["s"];
        }
    }
}