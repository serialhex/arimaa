﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using ZeroGravitas;

namespace Chimaera
{
    public class SquareBox : PictureBox
    {
        [Flags]
        public enum Highlight
        {
            Null = 0,
            Frozen = 1,
            Selected = 2
        }

        public PictureBox BackDrop { get; protected set; }
        protected Image[] ImageCache { get; set; }
        public int CurImageIndex { get; protected set; }
        public int FileIndex { get; protected set; }
        public int RankIndex { get; protected set; }
        public Highlight Highlights { get; protected set; }

        protected Square mSquare = null;
        public Square Square
        {
            get { return mSquare; }
            set
            {
                mSquare = value;
                this.Name = mSquare.Name;
            }
        }

        public SquareBox(PictureBox picBoardBackdrop, Image[] imageCache, int FileIndex, int RankIndex)
        {
            this.BackDrop = picBoardBackdrop;
            this.ImageCache = imageCache;
            this.FileIndex = FileIndex;
            this.RankIndex = RankIndex;

            this.CurImageIndex = -1;
            this.SizeMode = PictureBoxSizeMode.StretchImage;
            this.BackColor = Color.Transparent;

            picBoardBackdrop.Controls.Add(this);
            this.RefreshSizePos();
        }

        public void RefreshSizePos()
        {
            int width = this.BackDrop.Width / Board.NumFiles;
            int height = this.BackDrop.Height / Board.NumRanks;

            this.Top = height * (Board.MaxRankIndex - this.RankIndex);
            this.Left = width * this.FileIndex;
            this.Height = height;
            this.Width = width;
            this.Margin = new Padding(Math.Max((int)Math.Ceiling(width * 0.05), 4));
            this.Padding = new Padding(Math.Max((int)Math.Ceiling(width * 0.05), 4));
        }

        public bool SyncSquareImage()
        {
            Piece pc = this.Square.Piece;

            int newIndex = pc == null ? -1 : ((int)pc.Color * ru.NumPieceTypes) + (int)pc.PieceType - 1;

            if (this.CurImageIndex == newIndex)
                return false;

            if (newIndex > this.ImageCache.Length)
                return false;

            if (this.CurImageIndex != newIndex)
            {
                this.CurImageIndex = newIndex;
                this.Image = newIndex < 0 ? null : this.ImageCache[newIndex];
            }

            return true;
        }

        public void SetHighlight(bool isFriendlyPiece, bool isSelected, bool isFrozen)
        {
            Color c;
            Highlight highlights = Highlight.Null;
            if (isSelected)
                highlights |= Highlight.Selected;
            if (isFrozen)
                highlights |= Highlight.Frozen;

            switch (highlights)
            {
                case Highlight.Frozen | Highlight.Selected:
                    c = isFriendlyPiece ? Color.FromArgb(100, Color.Turquoise) : Color.FromArgb(100, Color.Violet);
                    break;
                case Highlight.Frozen:
                    c = isFriendlyPiece ? Color.FromArgb(100, Color.Blue) : Color.FromArgb(100, Color.Purple);
                    break;
                case Highlight.Selected:
                    c = isFriendlyPiece ? Color.FromArgb(100, Color.Yellow) : Color.FromArgb(100, Color.Red);
                    break;
                default:
                    c = Color.Transparent;
                    break;
            }

            if (this.BackColor != c)
                this.BackColor = c;
        }
    }
}
