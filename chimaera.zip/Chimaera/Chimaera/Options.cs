﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace Chimaera
{
    public class Options
    {
        public bool ShowFrozen { get; set; }
        public bool ReverseBoardWhenSilverMoves { get; set; }

        public Image ImageBoard { get; set; }
        //public Image[] ImageCachePieces { get; set; }
        public System.Collections.ObjectModel.ReadOnlyCollection<List<Image>> ImageCachePieces { get; set; }

        public delegate void delOptions(Options options);

        //public event delOptions ImageBoardChanged;
        //public event delOptions ImageCachePiecesChanged;
        //public event delOptions ViewOptionsChanged;
    }
}
