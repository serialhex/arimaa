﻿/*
 * Chimaera is a GUI for playing a chess variant called Arimaa®.
 * 
 * This project is provided with the written authorization of Arimaa.com
 * and in compliance with Section III of the Arimaa Public License. Any 
 * derivatives of this project must also comply with the Arimaa Public 
 * License. The Arimaa name is a registered trademark, and the Arimaa 
 * game is patented. The Arimaa rules, the Arimaa board, and the Arimaa 
 * piece design are all protected by copyright.

 * The latest revision of the Arimaa Public License can be found at:
 * http://arimaa.com/arimaa/license/current.txt
 * 
 * Please visit the official Arimaa web site.
 * http://arimaa.com/arimaa
 * 
 * The latest version of this project can always be found at:
 * http://www.wwddfd.com/arimaa/
 * 
 * Scott P Hensel
 * scott@wwddfd.com
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using ZeroGravitas;

namespace Chimaera
{
    public partial class Chimarea : Form
    {
        #region Enums & Events
        public enum UIState
        {
            Null,
            PieceSelected
        }

        public delegate void delNoArgs();
        public delegate void delArgSquareBox(SquareBox squarebox);
        public delegate void delArgMoveRecord(MoveRecord move);

        public event delArgMoveRecord PieceMoved;
        public event delArgSquareBox SelectedSquareChanged;
        public event delNoArgs GameStarted;
        public event delNoArgs TurnChanged;
        public event delNoArgs GameEnded;
        public event delNoArgs ViewOptionsChanged;
        #endregion Enums & Events

        #region Properties
        private Properties.Settings MySettings { get; set; }
        private Game CurGame = null;
        public SquareBox[,] SquareBoxes = null;

        public List<MoveRecord> LegalMoves { get; protected set; }
        private Image imgArimaaBoard = null;
        private Image[] pieceImageCache = null;
        public UIState State { get; protected set; }

        private bool mShowFrozen;
        public bool ShowFrozen
        {
            get { return mShowFrozen; }
            set
            {
                if (mShowFrozen == value)
                    return;

                mShowFrozen = value;
                this.ViewOptionsChanged();
            }
        }

        private SquareBox mSelectedSquareBox;
        public SquareBox SelectedSquareBox
        {
            get { return mSelectedSquareBox; }
            set
            {
                if (mSelectedSquareBox == value)
                    return;

                SquareBox tmp = mSelectedSquareBox;
                mSelectedSquareBox = value;
                this.SelectedSquareChanged(tmp);
            }
        }
        #endregion Properties

        public Chimarea()
        {
            InitializeComponent();
        }

        private void Chimarea_Load(object sender, EventArgs e)
        {
            this.SuspendLayout();

            MySettings = Properties.Settings.Default;
            this.LoadImages();
            this.Initialize();

            this.ResumeLayout();
            this.ShowFrozen = true; // DEBUG: Set ShowFrozen by default.
        }

        #region Initialization
        public void LoadImages()
        {
            imgArimaaBoard = Image.FromFile(Path.Combine(MySettings.ImageDirectory, MySettings.ImageBoard));
            picBoardBackdrop.BackgroundImage = imgArimaaBoard;
            picBoardBackdrop.BackgroundImageLayout = ImageLayout.Stretch;

            pieceImageCache = new Image[ru.NumPieceTypes * ru.NumPlayers];

            LoadImage(ae.PlayerColor.Gold, ae.PieceType.Rabbit, pieceImageCache, MySettings.ImageGoldRabbit);
            LoadImage(ae.PlayerColor.Gold, ae.PieceType.Cat, pieceImageCache, MySettings.ImageGoldCat);
            LoadImage(ae.PlayerColor.Gold, ae.PieceType.Dog, pieceImageCache, MySettings.ImageGoldDog);
            LoadImage(ae.PlayerColor.Gold, ae.PieceType.Horse, pieceImageCache, MySettings.ImageGoldHorse);
            LoadImage(ae.PlayerColor.Gold, ae.PieceType.Camel, pieceImageCache, MySettings.ImageGoldCamel);
            LoadImage(ae.PlayerColor.Gold, ae.PieceType.Elephant, pieceImageCache, MySettings.ImageGoldElephant);

            LoadImage(ae.PlayerColor.Silver, ae.PieceType.Rabbit, pieceImageCache, MySettings.ImageSilverRabbit);
            LoadImage(ae.PlayerColor.Silver, ae.PieceType.Cat, pieceImageCache, MySettings.ImageSilverCat);
            LoadImage(ae.PlayerColor.Silver, ae.PieceType.Dog, pieceImageCache, MySettings.ImageSilverDog);
            LoadImage(ae.PlayerColor.Silver, ae.PieceType.Horse, pieceImageCache, MySettings.ImageSilverHorse);
            LoadImage(ae.PlayerColor.Silver, ae.PieceType.Camel, pieceImageCache, MySettings.ImageSilverCamel);
            LoadImage(ae.PlayerColor.Silver, ae.PieceType.Elephant, pieceImageCache, MySettings.ImageSilverElephant);
        }

        public void Initialize()
        {
            this.lstTurns.Columns[1].Width -= SystemInformation.VerticalScrollBarWidth;

            this.LegalMoves = new List<MoveRecord>(4);

            this.SquareBoxes = new SquareBox[Board.NumFiles, Board.NumRanks];
            for (int RankIndex = 0; RankIndex < Board.NumRanks; ++RankIndex)
            {
                for (int FileIndex = 0; FileIndex < Board.NumFiles; ++FileIndex)
                {
                    SquareBox sq = new SquareBox(picBoardBackdrop, pieceImageCache, FileIndex, RankIndex);

                    sq.Click += new EventHandler(OnSquareBoxClick);
                    sq.Refresh();
                    SquareBoxes[FileIndex, RankIndex] = sq;
                }
            }

            this.SetGame(initCommonGame());

            this.PieceMoved += new delArgMoveRecord(OnPieceMoved);
            this.SelectedSquareChanged += new delArgSquareBox(OnSelectedSquareChanged);
            this.GameStarted += new delNoArgs(OnGameStarted);
            this.TurnChanged += new delNoArgs(OnTurnChanged);
            this.GameEnded += new delNoArgs(OnGameEnded);
            this.ViewOptionsChanged += new delNoArgs(OnViewOptionsChanged);

            this.TurnChanged();
        }

        public void SetGame(Game g)
        {
            this.CurGame = g;

            for (int RankIndex = 0; RankIndex < Board.NumRanks; ++RankIndex)
            {
                for (int FileIndex = 0; FileIndex < Board.NumFiles; ++FileIndex)
                {
                    SquareBox sq = SquareBoxes[FileIndex, RankIndex];
                    sq.Square = g.Board.GetSquare(FileIndex, RankIndex);
                }
            }
            this.lstTurns.Items.Clear();
            this.OnTurnChanged();
            this.OnSelectedSquareChanged(null);
            this.OnViewOptionsChanged();
        }
        #endregion Initialization

        #region Squares
        public void SquaresClearBackgrounds()
        {
            for (int RankIndex = 0; RankIndex < Board.NumRanks; ++RankIndex)
            {
                for (int FileIndex = 0; FileIndex < Board.NumFiles; ++FileIndex)
                {
                    SquareBox sq = SquareBoxes[FileIndex, RankIndex];
                    sq.SetHighlight(sq.Square.Piece != null && sq.Square.Piece.Color == this.CurGame.WhoseTurn.Color, sq == this.SelectedSquareBox, sq.Square.Piece != null && sq.Square.Piece.IsFrozen);

                    //sq.BackColor = Color.Transparent;
                    //if (this.ShowFrozen && sq.Square.Piece != null && sq.Square.Piece.IsFrozen)
                    //    sq.BackColor = Color.FromArgb(100, Color.Blue);
                }
            }
        }

        public void SquaresSync()
        {
            for (int RankIndex = 0; RankIndex < Board.NumRanks; ++RankIndex)
            {
                for (int FileIndex = 0; FileIndex < Board.NumFiles; ++FileIndex)
                {
                    SquareBox sq = SquareBoxes[FileIndex, RankIndex];
                    sq.SyncSquareImage();
                }
            }
        }
        #endregion Squares

        #region Event Handlers
        private void OnSquareBoxClick(object sender, EventArgs e)
        {
            if (sender is SquareBox)
            {
                SquareBox sq = (SquareBox)sender;

                if (this.SelectedSquareBox == sq)
                    return;

                if (sq.Square.Piece != null)
                    this.State = UIState.Null;

                if (this.SelectedSquareBox == null)
                    this.State = UIState.Null;
                else if (this.SelectedSquareBox.Square.GetDirectionToAdjacent(sq.Square) == ae.Direction.Null)
                    if (sq.Square.Piece != null)
                        this.State = UIState.Null;
                    else
                        return;

                switch (this.State)
                {
                    case UIState.Null:
                        {
                            if (sq.Square.Piece == null)
                                return;
                            this.SelectedSquareBox = sq;

                            break;
                        }
                    case UIState.PieceSelected:
                        {
                            MoveRecord move = new MoveRecord(this.CurGame.WhoseTurn, this.SelectedSquareBox.Square.Piece, this.SelectedSquareBox.Square, sq.Square);

                            try
                            {
                                this.CurGame.MakeMove(move);
                                this.SelectedSquareBox = sq.Square.Piece == null ? null : sq;
                                this.PieceMoved(move);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }
                            break;
                        }
                    default:
                        throw new InvalidOperationException("Unknown UI State!");
                }
            }
        }

        private void btnUndo_Click(object sender, EventArgs e)
        {
            try
            {
                List<MoveRecord> undoMoves = this.CurGame.UndoPrevMove();
                MoveRecord lastUndoMove = undoMoves.Count == 0 ? null : undoMoves[undoMoves.Count - 1];
                this.PieceMoved(lastUndoMove);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnEndTurn_Click(object sender, EventArgs e)
        {
            if (this.CurGame == null)
                return;

            try
            {

                this.SelectedSquareBox = null;

                switch (this.CurGame.StateType)
                {
                    case ae.GameStateType.Initialization:
                    case ae.GameStateType.Setup:
                        this.CurGame.StartGame();
                        this.OnGameStarted();
                        break;
                    case ae.GameStateType.Play:
                        this.CurGame.Advance();

                        switch (this.CurGame.State)
                        {
                            case ae.GameState.GoldWins:
                                MessageBox.Show("Gold wins!");
                                break;
                            case ae.GameState.SilverWins:
                                MessageBox.Show("Silver wins!");
                                break;
                            default:
                                break;
                        }

                        this.OnTurnChanged();
                        break;
                    case ae.GameStateType.Null:
                    case ae.GameStateType.End:
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void OnSelectedSquareChanged(SquareBox previousSelectedSquare)
        {
            this.SuspendLayout();
            this.SquaresClearBackgrounds();
            this.LegalMoves.Clear();

            if (this.SelectedSquareBox == null || this.SelectedSquareBox.Square.Piece == null)
            {
                this.State = UIState.Null;
            }
            else
            {
                this.State = UIState.PieceSelected;

                //if (this.SelectedSquareBox.Square.Piece.Color == this.CurGame.WhoseTurn.Color)
                //    this.SelectedSquareBox.BackColor = this.SelectedSquareBox.Square.Piece.IsFrozen ? Color.FromArgb(100, Color.Turquoise) : Color.FromArgb(100, Color.Yellow);
                //else
                //    this.SelectedSquareBox.BackColor = this.SelectedSquareBox.Square.Piece.IsFrozen ? Color.FromArgb(100, Color.Purple) : Color.FromArgb(100, Color.Red);
                this.SelectedSquareBox.SetHighlight(this.SelectedSquareBox.Square.Piece.Color == this.CurGame.WhoseTurn.Color, true, this.SelectedSquareBox.Square.Piece.IsFrozen);

                this.CurGame.AddLegalMoves(this.LegalMoves, this.SelectedSquareBox.Square.Piece);

                foreach (MoveRecord move in this.LegalMoves)
                {
                    this.SquareBoxes[move.To.File, move.To.Rank].BackColor = Color.FromArgb(100, Color.GreenYellow);
                }
            }
            this.ResumeLayout();
        }

        private void OnPieceMoved(MoveRecord move)
        {
            this.SuspendLayout();
            if (move != null)
            {
                if (move.To != null)
                {
                    this.SelectedSquareBox = SquareBoxes[move.To.File, move.To.Rank];
                }
            }
            this.SquaresSync();
            this.txtCurTurnMoves.Text = this.CurGame.MovesThisTurn;
            if (this.CurGame.MovesLeftThisTurn == 0)
            {
                this.btnEndTurn.BackColor = Color.Pink;
            }
            else
            {
                this.btnEndTurn.BackColor = Control.DefaultBackColor;
            }
            this.ResumeLayout();
        }

        private void OnGameStarted()
        {

        }

        private void OnTurnChanged()
        {
            this.SuspendLayout();
            this.lblCurTurn.Text = string.Format("{0}{1}", this.CurGame.TurnNumber, this.CurGame.WhoseTurn.Abbreviation);
            this.txtCurTurnMoves.Text = this.CurGame.MovesThisTurn;
            this.btnEndTurn.BackColor = Control.DefaultBackColor;

            if (this.CurGame.Turns.Count != this.lstTurns.Items.Count)
            {

                if (this.CurGame.Turns.Count > 1 && this.CurGame.Turns.Count == this.lstTurns.Items.Count + 2)
                {
                    TurnRecord t = this.CurGame.Turns[this.CurGame.Turns.Count - 2];
                    ListViewItem lvi = new ListViewItem(new string[] { t.Name, t.ToString() });
                    lstTurns.Items.Add(lvi);
                }
                else
                {
                    lstTurns.Items.Clear();
                    for (int i = 0; i < this.CurGame.Turns.Count - 1; ++i)
                    {
                        TurnRecord t = this.CurGame.Turns[i];
                        ListViewItem lvi = new ListViewItem(new string[] { t.Name, t.ToString() });
                        lstTurns.Items.Add(lvi);
                    }
                }
                lstTurns.EnsureVisible(lstTurns.Items.Count - 1);
            }
            this.ResumeLayout();
        }

        private void OnGameEnded()
        {

        }

        private void OnViewOptionsChanged()
        {
            this.SquaresClearBackgrounds();
            this.SquaresSync();
        }
        #endregion Event Handlers

        #region Helper Functions
        public Game initCommonGame()
        {
            Game g = new Game();
            g.InitializeFromBoardLayout(new string[]
                {
                "2g",
                " +-----------------+",
                "8| d c r h r r c d |",
                "7| r r m h r r r e |",
                "6|     x     x     |",
                "5|                 |",
                "4|                 |",
                "3|     x     x     |",
                "2| D C D H R H E M |",
                "1| C R R R R R R R |",
                " +-----------------+",
                "   a b c d e f g h  ",
                }
            );
            return g;
        }

        public Image LoadImage(string imageFileName)
        {
            Image tmp = Image.FromFile(Path.Combine(MySettings.ImageDirectory, imageFileName));
            return tmp;
        }

        public void LoadImage(ae.PlayerColor playerColor, ae.PieceType pieceType, Image[] images, string imageFileName)
        {
            images[((int)playerColor * ru.NumPieceTypes) + (int)pieceType - 1] = LoadImage(imageFileName);
        }
        #endregion Helper Functions

        #region Resize
        private void Chimarea_ResizeEnd(object sender, EventArgs e)
        {
            int ihdiff = this.MinimumSize.Height - 400;
            int iwdiff = this.MinimumSize.Width - 400;

            int nh = this.Height - ihdiff;
            int nw = this.Width - iwdiff;

            int maxdim = (int)(Math.Min(nh, nw) / Board.NumFiles) * Board.NumFiles;

            if (maxdim == this.picBoardBackdrop.Height)
                return;

            this.SuspendLayout();

            this.picBoardBackdrop.Hide();
            this.picBoardBackdrop.Height = maxdim;
            this.picBoardBackdrop.Width = maxdim;

            if (SquareBoxes != null)
            {
                for (int RankIndex = 0; RankIndex < Board.NumRanks; ++RankIndex)
                {
                    for (int FileIndex = 0; FileIndex < Board.NumFiles; ++FileIndex)
                    {
                        SquareBoxes[FileIndex, RankIndex].RefreshSizePos();
                    }
                }
            }
            this.picBoardBackdrop.Show();

            this.ResumeLayout();
            bResizing = false;
        }

        private void Chimarea_Resize(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Maximized || !bResizing)
                Chimarea_ResizeEnd(sender, e);
        }

        bool bResizing = false;
        private void Chimarea_ResizeBegin(object sender, EventArgs e)
        {
            bResizing = true;
        }
        #endregion Resize

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnUndo_Click(sender, e);
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(this.CurGame.Representation);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                string[] boardpos = Clipboard.GetText().Split('\n');
                Game g = new Game();
                g.InitializeFromBoardLayout(boardpos);
                this.SetGame(g);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
