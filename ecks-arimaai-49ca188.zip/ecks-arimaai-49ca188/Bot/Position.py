class Position:

  piece = 'R'
  row = 1
  col = 1
  dir = 'n'

  def __init__(self, piece, row, col, dir):
    self.piece = piece
    self.col = col
    self.row = row
    self.dir = dir

  
