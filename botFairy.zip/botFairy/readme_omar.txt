This readme file was added to the package by Omar Syed
to provide additional information.

botFairy is a sample (non-bitboard) Arimaa playing program written in C.
It was contributed by Ola Mikael Hansson (unic in the Arimaa gameroom).


For the original announcement about the public release of this
software, please see:

http://arimaa.com/arimaa/forum/cgi/YaBB.cgi?board=devTalk;action=display;num=1148667702

On Linux it can be compiled as:

  gcc -static -g -O3 board.c getMove.c search.c eval.c hash.c -o Fairy
 


