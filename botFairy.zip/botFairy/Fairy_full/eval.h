#ifndef EVALH_DEFINED // Don't include this twice

#define EVALH_DEFINED

int EVAL_Eval(board_t *bp, int verbose);

#endif
