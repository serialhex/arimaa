"""
  local paths
"""

root = __file__[:__file__.rfind('/')]

AKIMOT = '%s' % root
CXX_INCLUDE_DIR = '%s/include' % root
CXX_TEST_PATH = '%s/lib/python/cxxtestgen.py' % root
